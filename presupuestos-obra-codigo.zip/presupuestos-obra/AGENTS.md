# Instrucciones para agentes

Proyecto: **PWA de presupuestos de obra** para un albañil autónomo, usuario único y no técnico.
Antes de trabajar, lee `docs/00-contexto.md` y `docs/03-fase-1.md`.

## Reglas que no se negocian

- **Todo en español de España**, con vocabulario de obra (partida, m², ml, mano de obra).
  Interfaz, textos, nombres de campos visibles y documentación.
- **Sin registro, sin login, sin contraseñas, sin cuentas.** Es una decisión de producto, no un pendiente.
- **Sin IVA, sin facturación.** El importe es el que se le dice al cliente. Nada de base
  imponible, retenciones, Verifactu ni contabilidad.
- **Local-first**: los datos en IndexedDB. La app debe funcionar sin conexión en todo momento.
- **No llamar a Dexie desde componentes**: todo pasa por `src/lib/repo`.
- **Accesibilidad de uso real**: texto base 18–20 px, botones de 56 px, alto contraste,
  ningún icono sin etiqueta.
- **Nada se pierde**: autoguardado en cada cambio, sin botón "Guardar".
- **El catálogo «Mis precios» es central**: se alimenta del uso, no de una carga inicial.

## Fuera de alcance salvo petición explícita

Fotos, firma del cliente, logo, plantillas, sincronización en la nube, multiusuario, modo
oscuro, internacionalización, analítica, notificaciones, tests end-to-end, auditorías.

## Verificación

- `npm test` (cálculos y formato) y `npm run build` (tipos + build) tras cada cambio de código.
- Los tests de `src/lib/calculos.ts` son obligatorios: totales, céntimos, decimales.
- `pdf-lib` se importa dinámicamente en el editor: no lo importes arriba o el bundle inicial se dispara.
- La documentación de `docs/` se actualiza cuando cambie una decisión, no cuando cambie el código.
