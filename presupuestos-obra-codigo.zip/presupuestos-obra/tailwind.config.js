/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        papel: '#f6f4f0',
        tinta: '#1c1917',
        suave: '#6b6259',
        linea: '#e3ddd3',
        acento: {
          DEFAULT: '#a84a06',
          fuerte: '#8a3c04',
          claro: '#fdf1e3'
        },
        ok: '#15693a',
        mal: '#a3231b',
        info: '#1e4b8f'
      },
      fontFamily: {
        sans: [
          'system-ui',
          '-apple-system',
          'Segoe UI',
          'Roboto',
          'Helvetica Neue',
          'Arial',
          'sans-serif'
        ]
      }
    }
  },
  plugins: []
};
