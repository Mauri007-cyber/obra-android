# Guía técnica — Cómo presupuesta esta app y cómo llevarlo a otro proyecto

> Este documento explica **el modelo de presupuestación** que hay dentro de esta PWA, el
> contrato de datos, las reglas de cálculo y dónde vive cada cosa en el código.
> Está pensado para que puedas integrar esta forma de presupuestar en otro proyecto
> (otra app, otro backend, otro lenguaje) sin tener que leerte los 1.400 renglones de código.
>
> El resto de documentación de producto está en `docs/`. Empieza por `docs/00-contexto.md`
> si quieres el "por qué" y usa este archivo para el "cómo".

---

## Índice

1. [Qué hay en este zip](#1-qué-hay-en-este-zip)
2. [El modelo de presupuestación en 6 ideas](#2-el-modelo-de-presupuestación-en-6-ideas)
3. [Contrato de datos](#3-contrato-de-datos)
4. [El motor de cálculo (lo que no puede fallar)](#4-el-motor-de-cálculo-lo-que-no-puede-fallar)
5. [Ejemplo numérico completo](#5-ejemplo-numérico-completo)
6. [Cómo portarlo a otro proyecto](#6-cómo-portarlo-a-otro-proyecto)
7. [Reglas que no conviene romper](#7-reglas-que-no-conviene-romper)
8. [El PDF: plantilla y generación](#8-el-pdf-plantilla-y-generación)
9. [Pantallas y flujo de uso](#9-pantallas-y-flujo-de-uso)
10. [Mapa de archivos, uno a uno](#10-mapa-de-archivos-uno-a-uno)
11. [PWA: instalación y actualización sin perder datos](#11-pwa-instalación-y-actualización-sin-perder-datos)
12. [Copias de seguridad e importación](#12-copias-de-seguridad-e-importación)
13. [Puesta en marcha y despliegue](#13-puesta-en-marcha-y-despliegue)
14. [Límites conocidos](#14-límites-conocidos)
15. [Cómo justificarlo en una memoria de proyecto](#15-cómo-justificarlo-en-una-memoria-de-proyecto)
16. [Glosario](#16-glosario)

---

## 1. Qué hay en este zip

```
presupuestos-obra/
├── GUIA-TECNICA.md          ← este documento
├── README.md                ← puerta de entrada y comandos
├── AGENTS.md                ← reglas del proyecto (para trabajar con agentes)
├── docs/
│   ├── 00-contexto.md       ← usuario, decisiones de producto, estado
│   ├── 01-estrategia-producto.md
│   ├── 02-arquitectura.md
│   └── 03-fase-1.md         ← alcance del MVP con criterios de aceptación
├── src/
│   ├── db.ts                ← esquema de datos (tipos + Dexie)
│   ├── lib/                 ← cálculos, formato, datos, PDF, copias, PWA
│   ├── features/            ← pantallas (lista, editor, partidas, precios, ajustes)
│   └── ui/                  ← botón, campos, hoja, avisos, iconos
├── public/                  ← iconos de la PWA
├── scripts/gen-iconos.mjs   ← regenera los iconos (opcional)
├── index.html
├── package.json / package-lock.json
├── vite.config.ts / tsconfig.json
├── tailwind.config.js / postcss.config.js
├── sites.deploy.json + worker.js   ← despliegue estático (Cloudflare/Sites)
└── .gitignore
```

Lo que **no** incluye: `node_modules/` (se reinstala con `npm ci`), `dist/` (se genera con
`npm run build`), ni el historial de Git. No hace falta nada más para arrancar.

---

## 2. El modelo de presupuestación en 6 ideas

Esta es la parte que merece la pena reutilizar. Todo lo demás (React, Tailwind, IndexedDB)
es implementación sustituible.

### Idea 1 — Un presupuesto es un documento, no una fila de base de datos

`Presupuesto` lleva sus partidas **dentro** (`lineas: Linea[]`), igual que un PDF lleva sus
páginas. Ventajas directas:

- Se guarda y se lee de una sola vez, sin *joins* ni transacciones entre tablas.
- Al exportar una copia de seguridad, o al importarla en otro dispositivo, el documento
  viaja entero: no hay partidas huérfanas ni referencias rotas.
- El PDF se genera desde un único objeto ya cargado.

Es la decisión estructural más importante del proyecto. Si integras esto en una base de
datos relacional, la traducción natural es una tabla `presupuestos` y otra `partidas` con
`ON DELETE CASCADE`, pero **lee siempre el presupuesto completo antes de imprimir** y no
recalcules importes a partir del catálogo de precios actual (ver idea 3).

### Idea 2 — Dos modos de cobro, no uno

El usuario real de esta app no cobra siempre por m². Su forma habitual es:

> «Alicatar el baño: 1.000 €, material y mano de obra incluidos.»

Obligarle a inventarse metros para eso es fricción en cada partida. Por eso una partida
tiene **dos modos**:

| Modo | Cómo se guarda | Qué significa |
|---|---|---|
| **Partida entera** (por defecto) | `unidad: 'global'`, `cantidad: 1`, `precioUnitario: 1000` | Precio cerrado por el trabajo completo |
| **Por medida** | `unidad: 'm2' \| 'ml' \| 'ud' \| 'h' \| 'kg'`, `cantidad: 25`, `precioUnitario: 18` | Cantidad × precio unitario |

Detalle clave: **la partida entera no es una unidad de medida más**. `'global'` es un modo
de cobro. Por eso vive en el mismo campo `unidad` (para que el cálculo sea uno solo) pero la
UI lo trata aparte, y en el PDF la columna CANT. muestra «—» en lugar de «1 partida».

El modo se elige con dos botones grandes («Partida entera» / «Por medida») y la app
recuerda el modo al reutilizar un precio del catálogo.

### Idea 3 — El precio se congela en la línea

Cada `Linea` guarda **su propio** `precioUnitario`. El catálogo «Mis precios» solo sirve
para *rellenar* el formulario; cuando la partida se guarda, el precio queda copiado dentro
del presupuesto.

Consecuencia, y es intencionada: si mañana sube el precio del m² de alicatado en el
catálogo, **los presupuestos de la semana pasada no cambian**. Un presupuesto enviado al
cliente es un compromiso: su importe no puede moverse solo.

Lo mismo vale para el nombre del concepto y el tipo (material / mano de obra / todo
incluido): se copian. La única referencia que se conserva es `precioId` (opcional), y es
solo para estadísticas de uso, nunca para calcular.

### Idea 4 — El catálogo aprende del uso, no de una carga inicial

Nadie rellena un catálogo por gusto. «Mis precios» se llena solo:

- Al añadir una partida nueva con la casilla «Guardar en Mis precios» marcada
  (`recordarPrecio`), o al editarla con esa casilla.
- Si ya existe un precio con el **mismo concepto normalizado y la misma unidad**, no se
  duplica: se actualiza el precio, el tipo y se suma 1 a `vecesUsado`.
- Los 6 más usados aparecen como botones dentro del formulario de partida, a un toque.
- La lista de «Mis precios» se ordena por `vecesUsado` descendente.

La normalización del concepto quita tildes y mayúsculas (`normalizar` en `lib/formato.ts`),
así que «Alicatado de baño» y «ALICATADO DE BAÑO» son el mismo precio.

Ojo: el criterio de igualdad es **concepto + unidad**, no el tipo. «Alicatado» por m² y
«Alicatado» a precio cerrado son dos precios distintos y así debe ser.

### Idea 5 — Sin IVA, sin base imponible, sin facturas

No es un olvido: es una decisión de producto. Esto es una herramienta de organización
personal para decirle al cliente «son 4.350 €». El importe que se escribe es el importe que
se cobra. No hay tipos de IVA, descuentos, retenciones ni numeración fiscal.

Si tu proyecto **sí** necesita IVA, añádelo como un campo más y aplica el mismo principio
de la idea 3: guarda en la línea el tipo aplicado en el momento de presupuestar, no lo leas
del catálogo al imprimir. Y mantén el redondeo por línea antes de sumar (ver sección 4).

### Idea 6 — El presupuesto tiene un ciclo de vida corto y explícito

Cinco estados, sin máquina de estados compleja:

`borrador → enviado → aceptado / rechazado → terminado`

- Nace en `borrador`.
- Pasa a `enviado` automáticamente **solo la primera vez** que se comparte o descarga el
  PDF, y se guarda `enviadoEn`. Si ya estaba en otro estado, no se pisa.
- El resto se cambia a mano con botones (chips) en el editor.

La numeración también es deliberadamente simple: `serie-número` con tres dígitos
(`2026-001`, `2026-002`…). La serie por defecto es el año y el contador se guarda en
Ajustes. El número se asigna **al crear** el presupuesto, dentro de una transacción de
Dexie que también incrementa el contador, de modo que dos toques rápidos en «Nuevo» no
pueden generar el mismo número.

---

## 3. Contrato de datos

Estos son los tipos reales de `src/db.ts`. Si portas el modelo, este es el contrato mínimo.

```ts
type Unidad = 'm2' | 'ml' | 'ud' | 'h' | 'kg' | 'global';
type Estado = 'borrador' | 'enviado' | 'aceptado' | 'rechazado' | 'terminado';
type TipoPartida = 'material' | 'mano_obra' | 'mixto';

interface Linea {
  id: string;              // UUID generado en el cliente
  concepto: string;        // "Alicatado de baño"
  cantidad: number;        // 1 si es partida entera
  unidad: Unidad;          // 'global' = partida entera
  precioUnitario: number;  // copia congelada; en euros con decimales
  tipo: TipoPartida;
  precioId?: string;       // de qué precio del catálogo salió (solo trazabilidad)
}

interface Presupuesto {
  id: string;
  numero: string;            // "2026-014"
  clienteNombre: string;
  obraTitulo: string;
  obraDireccion?: string;
  fecha: string;             // ISO 8601
  validezDias: number;       // 30 por defecto
  estado: Estado;
  lineas: Linea[];
  notas?: string;            // texto libre que sale en el PDF
  creadoEn: string;
  actualizadoEn: string;     // se actualiza en cada guardado
  enviadoEn?: string;
}

interface Precio {           // catálogo "Mis precios"
  id: string;
  concepto: string;
  unidad: Unidad;
  precioUnitario: number;
  tipo: TipoPartida;
  vecesUsado: number;        // ordena la lista y los favoritos
  ultimaVez: string;
}

interface Ajustes {
  id: 'unico';               // fila única
  nombre: string;
  oficio: string;
  telefono: string;
  nif?: string;
  direccion?: string;
  validezDias: number;
  serie: string;             // "2026"
  siguienteNumero: number;
  ultimaCopia?: string;      // para el recordatorio de copia
}
```

### Invariantes (si los rompes, el modelo deja de funcionar)

1. `unidad === 'global'` ⇒ `cantidad === 1`. El formulario la fuerza; si escribes a mano,
   respétalo. Un `'global'` con cantidad 7 daría 7 veces el precio cerrado.
2. `precioUnitario` de la línea **nunca** se recalcula desde `Precio`.
3. `lineas` no se guarda en tabla aparte: es parte del documento.
4. `id` se genera en el cliente (`crypto.randomUUID()` con *fallback*). No hay servidor que
   asigne identificadores; eso es lo que permite crear presupuestos sin conexión e
   importarlos después sin colisiones.
5. `actualizadoEn` es la marca de conflicto al importar: gana el más reciente.
6. Los importes se guardan en **euros con decimales** (`1000`, `18.5`), no en céntimos
   enteros. El redondeo a céntimos se hace al calcular; ver sección 4.

---

## 4. El motor de cálculo (lo que no puede fallar)

`src/lib/calculos.ts` son 29 líneas. Es todo el motor. Cópialo tal cual.

```ts
export function redondear2(valor: number): number {
  return Math.round((valor + Number.EPSILON) * 100) / 100;
}

/** Importe de una partida, redondeado a céntimos. */
export function subtotalLinea(linea: Pick<Linea, 'cantidad' | 'precioUnitario'>): number {
  const cantidad = Number.isFinite(linea.cantidad) ? linea.cantidad : 0;
  const precio = Number.isFinite(linea.precioUnitario) ? linea.precioUnitario : 0;
  return redondear2(cantidad * precio);
}

/**
 * Total del presupuesto. Se suma en céntimos enteros para que el total
 * coincida exactamente con la suma de los importes que ve el cliente.
 */
export function totalPresupuesto(
  lineas: readonly Pick<Linea, 'cantidad' | 'precioUnitario'>[]
): number {
  const centimos = lineas.reduce((suma, linea) => {
    return suma + Math.round(subtotalLinea(linea) * 100);
  }, 0);
  return centimos / 100;
}
```

### Por qué está escrito así

- **Se redondea por línea, no al final.** El cliente ve el importe de cada partida en el
  PDF y luego el total. Si sumaras los valores sin redondear y redondearas al final, la
  suma de lo que ve podría diferir en un céntimo del total. Parece una tontería hasta que
  un cliente lo suma con la calculadora.
- **El total se acumula en céntimos enteros.** `0.1 + 0.2` en coma flotante da
  `0.30000000000000004`; sumar enteros y dividir al final elimina la deriva.
- **`Number.EPSILON`** corrige casos como `1.005 * 100 = 100.49999999999999`, que de otro
  modo redondearía a 100 céntimos en vez de 101.
- **Tolerancia a `NaN`/`Infinity`.** Un campo vacío o corrupto vale 0; nunca contamina el
  total con `NaN`.
- **Funciones puras, sin React ni base de datos.** Se testean en milisegundos y se pueden
  reutilizar en el PDF, en la lista y en el editor sin duplicar lógica.

El PDF usa **las mismas funciones** (`subtotalLinea` y `totalPresupuesto`). No hay una
segunda implementación de los cálculos en la plantilla: por construcción, lo que se ve en
pantalla y lo que sale en el PDF coincide.

### Tests

`src/lib/calculos.test.ts` (14 casos, `npm test`) cubre:

- multiplicación simple, cantidades decimales (2,5 m²), redondeo a céntimos;
- valores no numéricos → 0;
- partida entera = su precio cerrado;
- total de 0 partidas = 0;
- **invariante**: `total === Σ subtotal`, con `0,1 + 0,2` y con una mezcla de precios con
  céntimos (7 × 12,35 + 3 × 4,99 + 1,5 × 33,33);
- lectura de números escritos por una persona: `18,5`, `1.245,09`, `18.50`, `450 €`, vacío.

Si portas el modelo a otro lenguaje, **porta también estos casos**. Son la red de seguridad
del único cálculo que importa.

### Lectura de números (`parsearNumero`)

El usuario escribe con el teclado del móvil, que puede poner coma o punto. `parsearNumero`
acepta las dos convenciones:

| Entrada | Resultado | Regla aplicada |
|---|---|---|
| `18,5` | 18.5 | hay coma → los puntos son de miles |
| `1.245,09` | 1245.09 | ídem |
| `18.50` | 18.5 | sin coma; dos decimales tras el punto |
| `1.245` | 1245 | sin coma; 3 dígitos tras el punto y parte entera ≤ 3 → es un miles |
| `450 €` | 450 | se descarta todo lo que no sea dígito, coma, punto o signo |
| `''` | 0 | vacío no es error |

---

## 5. Ejemplo numérico completo

Presupuesto `2026-014`, cliente «María López», obra «Reforma de baño»:

| # | Concepto | Modo | Cantidad | Unidad | Precio | Importe |
|---|---|---|---|---|---|---|
| 1 | Alicatado de baño | entera | 1 | global | 1.000,00 € | 1.000,00 € |
| 2 | Solado de terraza | medida | 25 | m² | 18,00 €/m² | 450,00 € |
| 3 | Rodapié | medida | 12,5 | ml | 7,40 €/ml | 92,50 € |
| 4 | Retirada de escombros | entera | 1 | global | 180,00 € | 180,00 € |

Cálculo:

```
1.000,00 × 1      = 1.000,00
25 × 18,00        =   450,00
12,5 × 7,40       =    92,50
180,00 × 1        =   180,00
                    ---------
TOTAL             = 1.722,50 €
```

En el PDF, la columna CANT. muestra `—` en las líneas 1 y 4 (partida entera), `25 m²` en la
2 y `12,5 ml` en la 3. La columna PRECIO muestra el precio unitario en todas (`1.000,00 €`,
`18,00 €`, `7,40 €`, `180,00 €`).

---

## 6. Cómo portarlo a otro proyecto

### Nivel 1 — Solo el modelo conceptual (1 hora)

Llévate las secciones 2 y 3 de este documento. Define en tu proyecto:

- una entidad «presupuesto» con líneas embebidas;
- en cada línea, `modo` (entera/medida), `cantidad`, `unidad`, `precioUnitario` copiado;
- un catálogo de precios que se alimenta del uso.

No necesitas nada del código. Es un cambio de modelo de datos y de textos de interfaz.

### Nivel 2 — Modelo + cálculos (medio día)

Copia estos cuatro archivos, que no dependen de React ni de Dexie:

| Archivo | Qué aporta | Dependencias |
|---|---|---|
| `src/db.ts` | Tipos (`Linea`, `Presupuesto`, `Precio`, `Unidad`…) | `dexie` solo para la clase; los tipos son independientes |
| `src/lib/calculos.ts` | Subtotal, total, redondeo | solo el tipo `Linea` |
| `src/lib/formato.ts` | `euros`, `dinero`, `numero`, `parsearNumero`, `fecha`, `normalizar` | `Intl` nativo |
| `src/lib/unidades.ts` | Unidades, modos, tipos, etiquetas | el tipo `Unidad` |

Ajusta el tipo `Linea` a tu entidad y listo. `calculos.ts` solo necesita
`{ cantidad, precioUnitario }`, así que funciona con cualquier objeto que tenga esos dos
campos.

### Nivel 3 — Modelo + datos + PDF (dos o tres días)

Añade:

| Archivo | Qué aporta | Qué tendrás que cambiar |
|---|---|---|
| `src/lib/repo.ts` | Todas las operaciones de datos y hooks reactivos | Sustituye Dexie por tu almacenamiento; mantén la separación «los componentes no tocan la base de datos» |
| `src/lib/pdf.ts` | Plantilla A4 con `pdf-lib` | Colores, cabecera, textos legales |
| `src/lib/compartir.ts` | Web Share API + descarga | Nada, salvo el nombre del archivo |
| `src/lib/copia.ts` | Exportar/importar JSON | El campo `app` y la versión del formato |

### Ejemplo mínimo, sin React y sin Dexie

Así se usa el modelo desde cualquier código. Esto no está en el proyecto: es un ejemplo de
integración para que veas que el núcleo no depende de nada.

```ts
import { subtotalLinea, totalPresupuesto } from './lib/calculos';
import { nuevoId } from './lib/ids';

// 1. Crear una partida a precio cerrado
const partidaEntera = {
  id: nuevoId(),
  concepto: 'Alicatado de baño',
  cantidad: 1,
  unidad: 'global' as const,
  precioUnitario: 1000,
  tipo: 'mixto' as const
};

// 2. Crear una partida por medida
const partidaMedida = {
  id: nuevoId(),
  concepto: 'Solado de terraza',
  cantidad: 25,
  unidad: 'm2' as const,
  precioUnitario: 18,
  tipo: 'mixto' as const
};

// 3. Calcular (lo mismo que usa el PDF)
const lineas = [partidaEntera, partidaMedida];
console.log(subtotalLinea(partidaEntera));   // 1000
console.log(totalPresupuesto(lineas));       // 1450
```

### Si tu proyecto usa otra base de datos

Traducción directa a SQL, si tu proyecto lo pide:

```sql
CREATE TABLE presupuestos (
  id            TEXT PRIMARY KEY,
  numero        TEXT NOT NULL UNIQUE,
  cliente       TEXT NOT NULL DEFAULT '',
  obra          TEXT NOT NULL DEFAULT '',
  direccion     TEXT,
  fecha         TEXT NOT NULL,
  validez_dias  INTEGER NOT NULL DEFAULT 30,
  estado        TEXT NOT NULL DEFAULT 'borrador',
  notas         TEXT,
  creado_en     TEXT NOT NULL,
  actualizado_en TEXT NOT NULL,
  enviado_en    TEXT
);

CREATE TABLE partidas (
  id              TEXT PRIMARY KEY,
  presupuesto_id  TEXT NOT NULL REFERENCES presupuestos(id) ON DELETE CASCADE,
  orden           INTEGER NOT NULL,
  concepto        TEXT NOT NULL,
  cantidad        REAL NOT NULL DEFAULT 1,
  unidad          TEXT NOT NULL DEFAULT 'global',
  precio_unitario REAL NOT NULL DEFAULT 0,
  tipo            TEXT NOT NULL DEFAULT 'mixto',
  precio_id       TEXT
);

CREATE TABLE precios (
  id              TEXT PRIMARY KEY,
  concepto        TEXT NOT NULL,
  unidad          TEXT NOT NULL,
  precio_unitario REAL NOT NULL,
  tipo            TEXT NOT NULL,
  veces_usado     INTEGER NOT NULL DEFAULT 0,
  ultima_vez      TEXT NOT NULL
);
```

Nota: si tu base de datos guarda dinero, plantéate `INTEGER` en céntimos en lugar de `REAL`
en euros. Es más robusto; solo tendrás que dividir entre 100 al mostrar y multiplicar al
guardar. En esta PWA se guardan euros con decimales porque el volumen es mínimo y así el
JSON de copia de seguridad es legible por una persona.

### Qué adaptar y qué no

| Si tu proyecto… | Haz esto | No hagas esto |
|---|---|---|
| Necesita IVA | Añade `tipoIva` a la línea y calcula `subtotal × (1 + iva)` **después** del subtotal redondeado | No mezcles IVA dentro de `precioUnitario` |
| Necesita descuentos | Aplica el descuento a nivel de línea y redondea; documenta el orden | No descuentes sobre el total ya redondeado sin decirlo |
| Necesita varios usuarios | Añade `propietarioId` al presupuesto y filtra **en el servidor** | No confíes en un id que mande el cliente |
| Necesita sincronización | Mantén los ids del cliente y `actualizadoEn`; resuelve por «gana el más reciente» | No reasignes ids al subir |
| Ya tiene su propio catálogo | Reutiliza `recordarPrecio` como «aprender del uso» | No cargues cientos de precios de ejemplo: no se usan |

---

## 7. Reglas que no conviene romper

Estas son las trampas que este proyecto ya pagó. Si cambias una, cambia también los tests.

1. **Un solo redondeo, por línea.** Si redondeas en el editor, en la lista y en el PDF por
   separado, aparecerán diferencias de un céntimo. Usa las mismas funciones en los tres
   sitios (aquí: `subtotalLinea` y `totalPresupuesto`).
2. **El total se suma en céntimos enteros.** Sumar `number` en euros y redondear al final
   descuadra con muchas líneas.
3. **El precio de la línea es inmutable respecto al catálogo.** Editar «Mis precios» no
   puede reescribir el pasado. Es la diferencia entre un presupuesto y una hoja de cálculo.
4. **`'global'` siempre con `cantidad: 1`.** Si necesitas «3 baños a 1.000 €», o creas tres
   partidas o usas una unidad nueva con su propio significado. No reutilices `'global'` con
   cantidad.
5. **No calcules el total desde el catálogo.** El catálogo es una ayuda de entrada, no la
   fuente de verdad del documento.
6. **Guarda el número antes de imprimir.** En esta app el número se asigna al crear, no al
   enviar; así el PDF nunca sale sin numerar, ni siquiera en borrador.
7. **El PDF no recalcula nada por su cuenta.** Recibe el presupuesto ya guardado y usa las
   funciones de cálculo. Si el PDF tuviera su propia aritmética, tarde o temprano
   discreparía de la pantalla.
8. **La vista previa es el PDF real, no una maqueta HTML.** Aquí se genera el PDF y se
   rasteriza con pdf.js. Una maqueta paralela se desincroniza en cuanto cambias un margen.

---

## 8. El PDF: plantilla y generación

`src/lib/pdf.ts` genera un A4 (595,28 × 841,89 pt, margen 46 pt) con `pdf-lib`, en el
dispositivo, sin servidor. Estructura:

1. **Cabecera**: nombre del autónomo en mayúsculas, línea de contacto (oficio · teléfono ·
   NIF · dirección), y a la derecha «PRESUPUESTO», número grande y fecha.
2. **Cliente y obra** en dos columnas, con la dirección de la obra debajo.
3. **Tabla de partidas**: franja de cabecera (CONCEPTO · CANT. · PRECIO · IMPORTE) y una
   fila por partida con separador fino. Los conceptos largos se envuelven por palabras y,
   si una palabra no cabe, se parte por caracteres.
4. **Total**: línea horizontal, «TOTAL» y el importe en 19 pt.
5. **Validez**: «Presupuesto válido durante N días desde la fecha de emisión.»
6. **Notas** (si las hay).
7. **Firma del cliente** y fecha, con dos líneas.
8. **Pie** en cada página: `Presupuesto 2026-014 · página 1 de 3`.

Detalles de implementación que importan:

- **Saltos de página**: cuando `y` baja de 150 pt se añade página con cabecera reducida
  (número + fecha) y se repite la cabecera de la tabla. El bloque de total y firma también
  controla el espacio que le queda.
- **Fuentes estándar (Helvetica)**: no se incrustan fuentes, así que el PDF pesa poco, pero
  solo admiten el juego WinAnsi. `limpiar()` sustituye comillas tipográficas, guiones largos
  y puntos suspensivos, y elimina emojis o caracteres fuera de rango. Sin eso, `pdf-lib`
  lanza una excepción al dibujar un nombre con un icono.
- **`pdf-lib` se importa dinámicamente** en el editor (`await import('../../lib/pdf')`), solo
  al pulsar «Ver y enviar». Si lo importaras arriba, el bundle inicial crecería sin
  necesidad y la PWA tardaría más en abrir en obra.
- **Nombre del archivo**: `Presupuesto 2026-014 - María López.pdf`, con los caracteres
  prohibidos en nombres de archivo eliminados. Es lo que se ve en el WhatsApp del cliente.
- **Vista previa**: `src/lib/vistaPrevia.ts` carga `pdfjs-dist` también en dinámico,
  rasteriza cada página a JPEG (escala entre 1,4 y 2 según la densidad de pantalla) y las
  muestra como imágenes en un modal opaco. Si falla, queda el botón «Abrir el PDF».

Para adaptar la plantilla a tu proyecto, toca solo las constantes del principio (tamaño,
margen, colores, columnas) y los textos. La lógica de paginación no hace falta tocarla.

---

## 9. Pantallas y flujo de uso

No hay router: `src/App.tsx` guarda en estado qué vista está abierta. Son cuatro:

```
┌─ Lista ──────────────┐   ┌─ Editor ─────────────┐
│ buscador             │   │ cliente / obra       │
│ tarjetas con total   │──▶│ partidas + total     │
│ + Nuevo presupuesto  │   │ Ver y enviar ────────┼──▶ Vista previa ──▶ PDF / WhatsApp
└──────┬───────────────┘   └──────────────────────┘
       │ pestañas
       ├──▶ Mis precios  (catálogo, buscador, alta/edición/baja con deshacer)
       └──▶ Ajustes      (datos, numeración, copia de seguridad, instalar)
```

Flujo real del usuario, en cuatro pasos:

1. **Nuevo presupuesto** → se crea con número y se abre el editor.
2. **Rellenar cliente y obra** (opcional todo: nunca se bloquea el guardado).
3. **Añadir partidas**: una hoja a pantalla completa con concepto, modo de cobro, precio,
   tipo y los 6 precios más usados. El subtotal se ve en vivo («Va a salir: 450,00 €»).
4. **Ver y enviar** → se genera el PDF, se muestra tal cual y se comparte por el menú del
   sistema (WhatsApp). Al compartir, el presupuesto pasa a «Enviado».

Detalles de interacción que sostienen el uso real (padre no técnico, en obra, con guantes):

- **Autoguardado a los 350 ms** de cada cambio; sin botón «Guardar». Al salir del editor se
  guarda de inmediato; al desmontarse también.
- **Total siempre visible** en una barra inferior fija, en 24 px.
- **Deshacer** al borrar una partida o un precio (aviso inferior, 8 s).
- **Nada bloquea**: se puede guardar una partida sin cliente, sin dirección y sin notas.
- **Botones de 56 px** (`h-14`) y 64 px para las acciones principales (`grande`), texto base
  18 px, totales en 24–28 px, cabeceras de pantalla en 30 px.
- **Buscador tolerante**: sin tildes, insensible a mayúsculas, busca en cliente, obra y
  número.
- **Recordatorios pasivos** en la lista: si falta el nombre en Ajustes, aviso para ponerlo;
  si hay 3+ presupuestos y la última copia tiene más de 15 días, aviso de copia.

---

## 10. Mapa de archivos, uno a uno

### Raíz

| Archivo | Qué es | Cuándo tocarlo |
|---|---|---|
| `index.html` | Documento único; `lang="es"`, `viewport-fit=cover`, color de tema, icono | Cambiar título o metadatos |
| `package.json` | Dependencias y scripts (`dev`, `build`, `test`, `iconos`) | Añadir una librería |
| `vite.config.ts` | React + PWA (manifest, Workbox, estrategia de actualización) + servidor | Cambiar nombre/colores de la PWA o el puerto |
| `tailwind.config.js` | Tokens de color (`papel`, `tinta`, `acento`…) y tipografía del sistema | Cambiar la identidad visual |
| `postcss.config.js` | Tailwind + autoprefixer | Casi nunca |
| `tsconfig.json` | TypeScript estricto, JSX de React | Casi nunca |
| `worker.js` + `sites.deploy.json` | Worker mínimo que sirve `dist/` como estático | Solo si cambias de hosting |
| `AGENTS.md` | Reglas del proyecto para trabajar con agentes | Si cambian las reglas de producto |
| `README.md` | Puerta de entrada, comandos, estructura | Al cambiar el arranque |

### `src/`

| Archivo | Qué hace | Dónde mirar si… |
|---|---|---|
| `main.tsx` | Monta React y arranca la vigilancia de actualizaciones | …la app no arranca |
| `App.tsx` | Navegación por estado, pestañas inferiores, proveedor de avisos | …quieres añadir una pantalla |
| `db.ts` | Tipos del dominio y esquema Dexie (versión 1, cuatro tablas) | …cambias el modelo de datos |
| `index.css` | Tailwind, tamaño base 18 px, números tabulares | …cambias tipografía global |
| **`lib/calculos.ts`** | **Subtotal por línea y total, redondeo a céntimos** | **…hay un descuadre de importes** |
| `lib/calculos.test.ts` | 14 tests de cálculo y lectura de números | …cambias una regla de cálculo |
| `lib/formato.ts` | Euros, números, fechas es-ES, `normalizar`, `parsearNumero` | …un importe se muestra mal |
| `lib/unidades.ts` | Unidades, modos de cobro, tipos, etiquetas | …añades una unidad (pe. `m3`) |
| `lib/ids.ts` | UUID con *fallback* | Casi nunca |
| **`lib/repo.ts`** | **Única puerta a los datos**: crear, guardar, borrar, catálogo, ajustes, hooks `useLiveQuery` | **…quieres cambiar de almacenamiento** |
| `lib/pdf.ts` | Plantilla A4 y generación del PDF | …cambias el diseño del presupuesto |
| `lib/vistaPrevia.ts` | Rasteriza el PDF a imágenes con pdf.js | …la vista previa no carga |
| `lib/compartir.ts` | Web Share API nivel 2 y descarga de respaldo | …el PDF no se comparte en algún móvil |
| `lib/copia.ts` | Exportar/importar JSON, fusión por id y fecha | …cambias el formato de copia |
| `lib/actualizar.ts` | Comprueba versión y recarga sin perder lo escrito | …la app no se actualiza |
| `features/presupuestos/Lista.tsx` | Lista, buscador, estados, totales, recordatorios | …cambias la pantalla inicial |
| `features/presupuestos/Editor.tsx` | Cabecera, partidas, estado, total, autoguardado, vista previa | …cambias el flujo del presupuesto |
| `features/presupuestos/VistaPrevia.tsx` | Modal con las páginas del PDF y botón Enviar | …cambias la vista previa |
| `features/partidas/FormularioPartida.tsx` | Hoja de alta/edición de partida y elección de modo | …cambias cómo se introduce una partida |
| `features/precios/Precios.tsx` | Catálogo: lista por uso, buscador, alta/edición/baja | …cambias «Mis precios» |
| `features/ajustes/Ajustes.tsx` | Datos propios, numeración, copias, instrucciones de instalación | …cambias los ajustes |
| `ui/Boton.tsx` | Botón con variantes y tamaño `grande` (64 px) | …cambias la jerarquía de acciones |
| `ui/Campo.tsx` / `CampoNumero.tsx` | Campos de texto y numéricos (coma decimal, sufijo, ayuda) | …un campo se comporta mal |
| `ui/Chips.tsx` | Selector de opciones en pastillas | …añades opciones |
| `ui/Estado.tsx` | Los cinco estados y su chip de color | …cambias el ciclo de vida |
| `ui/Hoja.tsx` | Pantalla modal a tamaño completo con cabecera y pie fijo | …cambias el patrón de formularios |
| `ui/aviso.tsx` | Avisos inferiores con acción «Deshacer» | …cambias los mensajes |
| `ui/Iconos.tsx` | Set propio de iconos SVG inline (24×24, `currentColor`) | …añades un icono |

### `docs/`

| Documento | Para qué |
|---|---|
| `00-contexto.md` | Usuario, decisiones (D1–D11), estado, supuestos, glosario |
| `01-estrategia-producto.md` | Objetivos, anti-objetivos, UX, flujos y bocetos |
| `02-arquitectura.md` | Opciones evaluadas, stack, modelo, PWA, PDF, copias |
| `03-fase-1.md` | Alcance del MVP, backlog con criterios de aceptación, validación |

---

## 11. PWA: instalación y actualización sin perder datos

La app se instala desde el navegador («Añadir a pantalla de inicio»), se abre a pantalla
completa y funciona sin conexión desde la primera visita, porque Workbox precachea el shell
(JS, CSS, HTML, PNG, SVG, WOFF2) y sirve `index.html` como *fallback* de navegación.

La parte delicada es la actualización. El requisito de producto era: **que se actualice
sola, pero que no pierda nunca lo que está escribiendo**. Cómo se resuelve
(`src/lib/actualizar.ts` + `vite.config.ts`):

1. `registerType: 'prompt'`, `skipWaiting: false`: la versión nueva **no** entra en caliente.
2. `clientsClaim: true`: cuando se activa, toma el control de la pestaña y esta se recarga.
3. La app busca versión nueva **al abrir, al recuperar conexión, al volver a primer plano y
   cada 30 minutos**.
4. Antes de aplicar nada comprueba `algoEnUso()`: si hay un campo con el foco o algún
   elemento con `data-en-uso` (hoja de partida, vista previa), espera. Reintenta cada minuto.
5. Cuando puede, emite el evento `presupuestos:guardar-ya`; el editor lo escucha, cancela el
   temporizador y guarda de inmediato. 400 ms después activa la versión nueva.
6. Al cambiar el controlador (`controllerchange`), recarga la página.

Como los datos están en IndexedDB y el esquema no cambia entre versiones, la recarga no
toca nada del usuario. Esto se verificó en producción con dos builds reales: la pestaña se
recargó sola y el presupuesto seguía en la lista.

Detalle de diseño: los modales llevan `data-en-uso` justamente para que la actualización no
los cierre a mitad de una edición. Si añades una pantalla modal nueva, ponle ese atributo.

---

## 12. Copias de seguridad e importación

Formato del archivo (`presupuestos-2026-11-20.json`):

```json
{
  "app": "presupuestos-obra",
  "version": 1,
  "exportadoEn": "2026-11-20T09:12:00.000Z",
  "ajustes": { "...": "..." },
  "presupuestos": [ { "...": "..." } ],
  "precios": [ { "...": "..." } ]
}
```

- **Exportar**: se crea el JSON, se comparte con el menú del sistema (WhatsApp, Drive…) y,
  si no se cancela, se marca `ultimaCopia`. La lista recuerda hacer copia si pasan 15 días.
- **Importar**: valida `app === 'presupuestos-obra'` y que `presupuestos` sea un array.
  - Presupuestos: se insertan si el `id` no existe; si existe y el `actualizadoEn` del
    archivo es más reciente, se sobrescribe. **Nunca borra** lo que hay en el móvil.
  - Precios: se insertan solo si el `id` no existe (no pisa ediciones locales).
  - Ajustes: solo si el dispositivo no tenía ninguno.
  - Todo dentro de una transacción: o entra completo, o no entra nada.

Esto permite usar el mismo JSON como traslado entre dispositivos sin cuentas ni nube.

---

## 13. Puesta en marcha y despliegue

Requisitos: Node 20+ y npm.

```bash
npm ci            # instala exactamente lo del package-lock
npm run dev       # desarrollo en http://localhost:3000
npm test          # 14 tests de cálculo y formato
npm run build     # tsc --noEmit + build estático + service worker en dist/
npm run preview   # sirve dist/ para comprobar el build
npm run iconos    # regenera los iconos de public/ (opcional)
```

El build deja en `dist/` todo lo necesario; es un sitio estático puro. En este proyecto se
despliega con el manifiesto `sites.deploy.json` (Worker que hace `env.ASSETS.fetch`), pero
sirve cualquier hosting de ficheros (Netlify, Vercel, GitHub Pages, un Apache…). Si lo pones
en un subdirectorio, ajusta `base` en `vite.config.ts` y `start_url`/`scope` del manifest.

Datos y dominios: IndexedDB está atado al origen. Lo creado en `localhost` no aparece en
producción, y lo del preview no aparece en producción. Es normal, no es un fallo.

---

## 14. Límites conocidos

- **Sin sincronización ni multiusuario.** Los datos viven en un dispositivo. La copia JSON
  es el único traslado. El diseño de `repo.ts` deja la puerta abierta a un backend, pero no
  está hecho.
- **Sin IVA ni facturación**, por decisión de producto (ver `docs/00-contexto.md`, D5).
- **Sin fotos, firma digital, logo ni plantillas.** Están en fases posteriores.
- **El PDF usa fuentes estándar**: no admite alfabetos no latinos ni emojis; `limpiar()` los
  descarta. Para chino, árabe o similares habría que incrustar una fuente TTF.
- **Los importes se guardan en euros con decimales** (no en céntimos enteros). Para el
  volumen de esta app es suficiente; si integras el modelo en un sistema con más tráfico o
  más cálculos, usa enteros.
- **Un único perfil** (`Ajustes` con `id: 'unico'`).
- **No hay tests de interfaz ni end-to-end**: solo cálculo y formato, por decisión de fase.
- **La tabla `clientes` existe en el esquema pero no se usa todavía**: el nombre del cliente
  se escribe a mano en cada presupuesto. Es deuda consciente, no un fallo.

---

## 15. Cómo justificarlo en una memoria de proyecto

Si vas a presentar esto como proyecto (FP, universidad, portafolio), estos son los puntos
defendibles, con la evidencia en el código:

1. **El modelo nace del usuario, no de la tecnología.** Dos modos de cobro porque el
   albañil real cobra por partida cerrada la mayoría de las veces (D10 en
   `docs/00-contexto.md`). Es el argumento más fuerte del proyecto.
2. **Local-first como decisión, no como limitación.** Sin login, sin red, sin coste de
   servidor; y una capa `repo.ts` que permite añadir nube después sin tocar pantallas
   (D2, D7).
3. **Corrección monetaria demostrable.** Redondeo por línea y suma en céntimos, con tests
   que incluyen el invariante «total = suma de lo mostrado». Enseña
   `src/lib/calculos.test.ts`.
4. **Inmutabilidad del documento.** El precio se congela en la línea; editar el catálogo no
   reescribe presupuestos pasados. Es la diferencia entre un presupuesto y una hoja de
   cálculo, y se explica solo.
5. **El PDF es el producto.** No es una exportación secundaria: es lo que el cliente ve. Por
   eso hay vista previa del PDF real y el archivo se comparte por el menú del sistema.
6. **Accesibilidad de uso real, con criterios medibles.** Texto base 18 px, acciones de
   56–64 px, contraste alto, ningún icono sin etiqueta, una cosa por pantalla.
7. **Robustez probada en producción.** Actualización automática sin pérdida de datos,
   verificada con dos builds reales; autoguardado con *flush* al salir y antes de recargar;
   copia de seguridad con fusión no destructiva.

Y los límites, dichos sin rodeos: un solo usuario, sin nube, sin IVA, sin tests de interfaz.
Reconocerlos vale más que esconderlos.

---

## 16. Glosario

- **Partida**: cada línea del presupuesto («Alicatado de baño, 25 m², 18 €/m²»).
- **Partida entera / precio cerrado**: se cobra el trabajo completo en un solo importe, con
  material y mano de obra incluidos; sin metros ni cantidades. En datos: `unidad: 'global'`.
- **Presupuesto**: documento con precio total que se entrega al cliente. No es una factura.
- **Obra**: el encargo concreto para un cliente (reforma de baño, solado de terraza…).
- **Catálogo / Mis precios**: precios propios que se reutilizan; se alimenta del uso.
- **m², ml, ud, h, kg**: unidades para cuando sí se cobra por medida (metro cuadrado, metro
  lineal, unidad, hora, kilo).
- **Borrador / enviado / aceptado / rechazado / terminado**: los cinco estados.
- **Copia de seguridad**: archivo JSON con todo, para restaurar o cambiar de móvil.
