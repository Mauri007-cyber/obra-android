import type { Linea } from '../db';

export function redondear2(valor: number): number {
  return Math.round((valor + Number.EPSILON) * 100) / 100;
}

/** Importe de una partida, redondeado a céntimos. */
export function subtotalLinea(linea: Pick<Linea, 'cantidad' | 'precioUnitario'>): number {
  const cantidad = Number.isFinite(linea.cantidad) ? linea.cantidad : 0;
  const precio = Number.isFinite(linea.precioUnitario) ? linea.precioUnitario : 0;
  return redondear2(cantidad * precio);
}

/**
 * Total del presupuesto. Se suma en céntimos enteros para que el total
 * coincida exactamente con la suma de los importes que ve el cliente.
 */
export function totalPresupuesto(
  lineas: readonly Pick<Linea, 'cantidad' | 'precioUnitario'>[]
): number {
  const centimos = lineas.reduce((suma, linea) => {
    return suma + Math.round(subtotalLinea(linea) * 100);
  }, 0);
  return centimos / 100;
}

export function contarLineas(lineas: readonly unknown[]): number {
  return lineas.length;
}
