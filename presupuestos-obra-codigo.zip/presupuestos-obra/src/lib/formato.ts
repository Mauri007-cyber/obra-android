const formateadorEuros = new Intl.NumberFormat('es-ES', {
  style: 'currency',
  currency: 'EUR',
  minimumFractionDigits: 2,
  maximumFractionDigits: 2
});

const formateadorNumero = new Intl.NumberFormat('es-ES', {
  minimumFractionDigits: 0,
  maximumFractionDigits: 2
});

const formateadorDecimales = new Intl.NumberFormat('es-ES', {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2
});

/** Importe para pantalla: 1.245,09 € */
export function euros(valor: number): string {
  return formateadorEuros.format(Number.isFinite(valor) ? valor : 0);
}

/** Importe sin símbolo, con espacio normal (para el PDF): 1.245,09 € */
export function dinero(valor: number): string {
  return `${formateadorDecimales.format(Number.isFinite(valor) ? valor : 0)} €`;
}

/** Cantidad: 25 · 2,5 */
export function numero(valor: number): string {
  return formateadorNumero.format(Number.isFinite(valor) ? valor : 0);
}

export function fecha(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '';
  return new Intl.DateTimeFormat('es-ES', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric'
  }).format(d);
}

export function fechaLarga(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '';
  return new Intl.DateTimeFormat('es-ES', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  }).format(d);
}

/** Texto comparable para buscador: sin tildes, en minúsculas. */
export function normalizar(texto: string): string {
  return texto
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .trim();
}

/** Lee lo que escribe una persona: "1.245,09" · "18,5" · "18.50" */
export function parsearNumero(texto: string): number {
  const limpio = texto.replace(/[^\d.,-]/g, '').trim();
  if (!limpio) return 0;

  let normalizado = limpio;
  if (limpio.includes(',')) {
    normalizado = limpio.replace(/\./g, '').replace(',', '.');
  } else {
    const partes = limpio.split('.');
    if (partes.length > 2) {
      normalizado = limpio.replace(/\./g, '');
    } else if (partes.length === 2 && partes[1].length === 3 && partes[0].length <= 3) {
      normalizado = `${partes[0]}${partes[1]}`;
    }
  }

  const valor = Number(normalizado);
  return Number.isFinite(valor) ? valor : 0;
}

/** Número para escribir en un campo: 18,5 */
export function aTexto(valor: number): string {
  if (!Number.isFinite(valor) || valor === 0) return '';
  return String(valor).replace('.', ',');
}
