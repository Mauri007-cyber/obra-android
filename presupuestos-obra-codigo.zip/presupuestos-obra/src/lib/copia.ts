import { db, type Ajustes, type Presupuesto, type Precio } from '../db';
import { compartirArchivo } from './compartir';
import { marcarCopia } from './repo';

export interface Copia {
  app: 'presupuestos-obra';
  version: 1;
  exportadoEn: string;
  ajustes?: Ajustes;
  presupuestos: Presupuesto[];
  precios: Precio[];
}

export function nombreCopia(fecha = new Date()): string {
  const iso = fecha.toISOString().slice(0, 10);
  return `presupuestos-${iso}.json`;
}

export async function crearCopia(): Promise<Copia> {
  const [ajustes, presupuestos, precios] = await Promise.all([
    db.ajustes.get('unico'),
    db.presupuestos.toArray(),
    db.precios.toArray()
  ]);
  return {
    app: 'presupuestos-obra',
    version: 1,
    exportadoEn: new Date().toISOString(),
    ajustes,
    presupuestos,
    precios
  };
}

export async function exportarCopia(): Promise<string> {
  const copia = await crearCopia();
  const blob = new Blob([JSON.stringify(copia, null, 2)], { type: 'application/json' });
  const nombre = nombreCopia();
  const resultado = await compartirArchivo(blob, nombre);
  if (resultado !== 'cancelado') await marcarCopia();
  return resultado;
}

export async function importarCopia(texto: string): Promise<{ presupuestos: number; precios: number }> {
  let datos: Partial<Copia>;
  try {
    datos = JSON.parse(texto) as Partial<Copia>;
  } catch {
    throw new Error('El archivo no se puede leer.');
  }

  if (!datos || datos.app !== 'presupuestos-obra' || !Array.isArray(datos.presupuestos)) {
    throw new Error('El archivo no es una copia de esta aplicación.');
  }

  let presupuestosNuevos = 0;
  let preciosNuevos = 0;

  await db.transaction('rw', db.presupuestos, db.precios, db.ajustes, async () => {
    for (const presupuesto of datos.presupuestos ?? []) {
      if (!presupuesto?.id || !Array.isArray(presupuesto.lineas)) continue;
      const local = await db.presupuestos.get(presupuesto.id);
      if (!local) {
        await db.presupuestos.put(presupuesto);
        presupuestosNuevos += 1;
      } else if (
        new Date(presupuesto.actualizadoEn).getTime() > new Date(local.actualizadoEn).getTime()
      ) {
        await db.presupuestos.put(presupuesto);
        presupuestosNuevos += 1;
      }
    }

    for (const precio of datos.precios ?? []) {
      if (!precio?.id) continue;
      const local = await db.precios.get(precio.id);
      if (!local) {
        await db.precios.put(precio);
        preciosNuevos += 1;
      }
    }

    const ajustesLocales = await db.ajustes.get('unico');
    if (!ajustesLocales && datos.ajustes) {
      await db.ajustes.put({ ...datos.ajustes, id: 'unico' });
    }
  });

  return { presupuestos: presupuestosNuevos, precios: preciosNuevos };
}
