import { PDFDocument, StandardFonts, rgb, type PDFFont, type PDFPage } from 'pdf-lib';
import type { Ajustes, Presupuesto } from '../db';
import { dinero, fecha, numero } from './formato';
import { subtotalLinea, totalPresupuesto } from './calculos';
import { etiquetaUnidad } from './unidades';

const A4: [number, number] = [595.28, 841.89];
const MARGEN = 46;
const DERECHA = A4[0] - MARGEN;

const TINTA = rgb(0.11, 0.098, 0.09);
const GRIS = rgb(0.42, 0.384, 0.349);
const LINEA = rgb(0.89, 0.867, 0.827);
const FONDO = rgb(0.965, 0.957, 0.941);

const COL_CANT = 382;
const COL_PRECIO = 468;
const ANCHO_CONCEPTO = 300;

type OpcionesTexto = { fuente?: PDFFont; tamano?: number; color?: ReturnType<typeof rgb> };

/** Deja solo caracteres que las fuentes estándar del PDF saben dibujar. */
function limpiar(texto: string): string {
  return texto
    .replace(/[\u2018\u2019]/g, "'")
    .replace(/[\u201c\u201d]/g, '"')
    .replace(/[\u2013\u2014]/g, '-')
    .replace(/\u2026/g, '...')
    .replace(/[^\t\n\r\x20-\x7e\u00a0-\u00ff\u20ac]/g, '');
}

function envolver(texto: string, fuente: PDFFont, tamano: number, ancho: number): string[] {
  const palabras = limpiar(texto).split(/\s+/).filter(Boolean);
  const lineas: string[] = [];
  let actual = '';

  for (const palabra of palabras) {
    const prueba = actual ? `${actual} ${palabra}` : palabra;
    if (fuente.widthOfTextAtSize(prueba, tamano) <= ancho) {
      actual = prueba;
      continue;
    }
    if (actual) lineas.push(actual);
    if (fuente.widthOfTextAtSize(palabra, tamano) > ancho) {
      let trozo = '';
      for (const caracter of palabra) {
        if (fuente.widthOfTextAtSize(trozo + caracter, tamano) > ancho) {
          lineas.push(trozo);
          trozo = caracter;
        } else {
          trozo += caracter;
        }
      }
      actual = trozo;
    } else {
      actual = palabra;
    }
  }
  if (actual) lineas.push(actual);
  return lineas.length ? lineas : [''];
}

export function nombreArchivo(presupuesto: Presupuesto): string {
  const limpiarNombre = (texto: string) => texto.replace(/[\\/:*?"<>|]/g, '').replace(/\s+/g, ' ').trim();
  const cliente = limpiarNombre(presupuesto.clienteNombre);
  return `Presupuesto ${presupuesto.numero}${cliente ? ` - ${cliente}` : ''}.pdf`;
}

export async function generarPdf(presupuesto: Presupuesto, ajustes: Ajustes): Promise<Blob> {
  const doc = await PDFDocument.create();
  const regular = await doc.embedFont(StandardFonts.Helvetica);
  const negrita = await doc.embedFont(StandardFonts.HelveticaBold);

  doc.setTitle(`Presupuesto ${presupuesto.numero}`);
  doc.setAuthor(limpiar(ajustes.nombre) || 'Presupuesto');
  doc.setSubject(limpiar(presupuesto.obraTitulo) || 'Presupuesto de obra');
  doc.setCreator('Presupuestos de obra');
  doc.setProducer('Presupuestos de obra');

  let pagina: PDFPage = doc.addPage(A4);
  let y = A4[1] - MARGEN;

  const escribir = (texto: string, x: number, posY: number, opciones: OpcionesTexto = {}) => {
    pagina.drawText(limpiar(texto), {
      x,
      y: posY,
      size: opciones.tamano ?? 10,
      font: opciones.fuente ?? regular,
      color: opciones.color ?? TINTA
    });
  };

  const escribirDerecha = (texto: string, xDerecha: number, posY: number, opciones: OpcionesTexto = {}) => {
    const fuente = opciones.fuente ?? regular;
    const tamano = opciones.tamano ?? 10;
    const limpio = limpiar(texto);
    escribir(limpio, xDerecha - fuente.widthOfTextAtSize(limpio, tamano), posY, opciones);
  };

  // ── Cabecera ──────────────────────────────────────────────────────────────
  escribir((ajustes.nombre || 'Presupuesto').toUpperCase(), MARGEN, y, {
    fuente: negrita,
    tamano: 15
  });

  const contacto = [
    ajustes.oficio,
    ajustes.telefono ? `Tel. ${ajustes.telefono}` : '',
    ajustes.nif ? `NIF ${ajustes.nif}` : '',
    ajustes.direccion ?? ''
  ]
    .filter(Boolean)
    .join('  ·  ');

  if (contacto) {
    const lineasContacto = envolver(contacto, regular, 9, 300);
    lineasContacto.slice(0, 2).forEach((linea, i) => {
      escribir(linea, MARGEN, y - 16 - i * 12, { tamano: 9, color: GRIS });
    });
  }

  escribirDerecha('PRESUPUESTO', DERECHA, y, { fuente: negrita, tamano: 8.5, color: GRIS });
  escribirDerecha(presupuesto.numero, DERECHA, y - 22, { fuente: negrita, tamano: 17 });
  escribirDerecha(`Fecha: ${fecha(presupuesto.fecha)}`, DERECHA, y - 38, {
    tamano: 9,
    color: GRIS
  });

  y -= 64;
  pagina.drawLine({ start: { x: MARGEN, y }, end: { x: DERECHA, y }, thickness: 0.9, color: LINEA });
  y -= 26;

  // ── Cliente y obra ────────────────────────────────────────────────────────
  const columnas: { x: number; ancho: number; etiqueta: string; valor: string; extra?: string }[] = [
    {
      x: MARGEN,
      ancho: 250,
      etiqueta: 'CLIENTE',
      valor: presupuesto.clienteNombre || 'Sin especificar'
    },
    {
      x: 320,
      ancho: 230,
      etiqueta: 'OBRA',
      valor: presupuesto.obraTitulo || 'Sin especificar',
      extra: presupuesto.obraDireccion
    }
  ];

  let altoBloque = 0;
  for (const col of columnas) {
    escribir(col.etiqueta, col.x, y, { fuente: negrita, tamano: 7.5, color: GRIS });
    const lineasValor = envolver(col.valor, negrita, 11, col.ancho);
    lineasValor.slice(0, 3).forEach((linea, i) => {
      escribir(linea, col.x, y - 16 - i * 13, { fuente: negrita, tamano: 11 });
    });
    let alto = 16 + lineasValor.slice(0, 3).length * 13;
    if (col.extra) {
      const lineasExtra = envolver(col.extra, regular, 9, col.ancho);
      lineasExtra.slice(0, 2).forEach((linea, i) => {
        escribir(linea, col.x, y - 16 - lineasValor.slice(0, 3).length * 13 - i * 11, {
          tamano: 9,
          color: GRIS
        });
      });
      alto += lineasExtra.slice(0, 2).length * 11;
    }
    altoBloque = Math.max(altoBloque, alto);
  }
  y -= altoBloque + 18;

  // ── Tabla de partidas ─────────────────────────────────────────────────────
  const cabeceraTabla = () => {
    pagina.drawRectangle({
      x: MARGEN,
      y: y - 20,
      width: DERECHA - MARGEN,
      height: 22,
      color: FONDO
    });
    escribir('CONCEPTO', MARGEN + 8, y - 14, { fuente: negrita, tamano: 7.5, color: GRIS });
    escribirDerecha('CANT.', COL_CANT, y - 14, { fuente: negrita, tamano: 7.5, color: GRIS });
    escribirDerecha('PRECIO', COL_PRECIO, y - 14, { fuente: negrita, tamano: 7.5, color: GRIS });
    escribirDerecha('IMPORTE', DERECHA, y - 14, { fuente: negrita, tamano: 7.5, color: GRIS });
    y -= 30;
  };

  const limiteInferior = 150;
  const saltoDePagina = () => {
    pagina = doc.addPage(A4);
    y = A4[1] - MARGEN;
    escribir(`Presupuesto ${presupuesto.numero}`, MARGEN, y, {
      fuente: negrita,
      tamano: 11
    });
    escribirDerecha(fecha(presupuesto.fecha), DERECHA, y, { tamano: 9, color: GRIS });
    y -= 22;
    pagina.drawLine({
      start: { x: MARGEN, y },
      end: { x: DERECHA, y },
      thickness: 0.7,
      color: LINEA
    });
    y -= 18;
    cabeceraTabla();
  };

  cabeceraTabla();

  if (presupuesto.lineas.length === 0) {
    escribir('Todavía no hay partidas en este presupuesto.', MARGEN + 8, y, {
      tamano: 10,
      color: GRIS
    });
    y -= 22;
  }

  for (const linea of presupuesto.lineas) {
    const lineasConcepto = envolver(linea.concepto || 'Partida sin nombre', regular, 9.5, ANCHO_CONCEPTO);
    const alto = Math.max(26, lineasConcepto.length * 12 + 12);

    if (y - alto < limiteInferior) saltoDePagina();

    lineasConcepto.forEach((texto, i) => {
      escribir(texto, MARGEN + 8, y - i * 12, { tamano: 9.5 });
    });

    const cantidad =
      linea.unidad === 'global'
        ? '—'
        : `${numero(linea.cantidad)} ${etiquetaUnidad(linea.unidad)}`;
    escribirDerecha(cantidad, COL_CANT, y, { tamano: 9, color: GRIS });
    escribirDerecha(dinero(linea.precioUnitario), COL_PRECIO, y, { tamano: 9, color: GRIS });
    escribirDerecha(dinero(subtotalLinea(linea)), DERECHA, y, { fuente: negrita, tamano: 9.5 });

    y -= alto - 12;
    pagina.drawLine({
      start: { x: MARGEN, y: y + 4 },
      end: { x: DERECHA, y: y + 4 },
      thickness: 0.5,
      color: FONDO
    });
    y -= 6;
  }

  // ── Total ─────────────────────────────────────────────────────────────────
  if (y < 190) saltoDePagina();
  y -= 6;
  pagina.drawLine({ start: { x: 380, y }, end: { x: DERECHA, y }, thickness: 1.1, color: TINTA });

  escribirDerecha('TOTAL', DERECHA, y - 18, { fuente: negrita, tamano: 8.5, color: GRIS });
  escribirDerecha(dinero(totalPresupuesto(presupuesto.lineas)), DERECHA, y - 44, {
    fuente: negrita,
    tamano: 19
  });

  escribir(
    `Presupuesto válido durante ${presupuesto.validezDias} días desde la fecha de emisión.`,
    MARGEN,
    y - 18,
    { tamano: 8.5, color: GRIS }
  );

  y -= 68;

  // ── Notas ─────────────────────────────────────────────────────────────────
  if (presupuesto.notas && presupuesto.notas.trim()) {
    if (y < 150) saltoDePagina();
    escribir('NOTAS', MARGEN, y, { fuente: negrita, tamano: 7.5, color: GRIS });
    const lineasNotas = envolver(presupuesto.notas, regular, 9, DERECHA - MARGEN);
    lineasNotas.forEach((linea, i) => {
      escribir(linea, MARGEN, y - 14 - i * 12, { tamano: 9, color: GRIS });
    });
    y -= 22 + lineasNotas.length * 12;
  }

  // ── Firma ─────────────────────────────────────────────────────────────────
  if (y < 130) saltoDePagina();
  const yFirma = Math.max(y - 30, 100);
  pagina.drawLine({
    start: { x: MARGEN, y: yFirma },
    end: { x: MARGEN + 170, y: yFirma },
    thickness: 0.8,
    color: TINTA
  });
  pagina.drawLine({
    start: { x: DERECHA - 120, y: yFirma },
    end: { x: DERECHA, y: yFirma },
    thickness: 0.8,
    color: TINTA
  });
  escribir('Firma del cliente', MARGEN, yFirma - 12, { tamano: 8, color: GRIS });
  escribirDerecha('Fecha', DERECHA, yFirma - 12, { tamano: 8, color: GRIS });

  // ── Pie de página ─────────────────────────────────────────────────────────
  const paginas = doc.getPages();
  paginas.forEach((p, indice) => {
    const texto = `Presupuesto ${presupuesto.numero}  ·  página ${indice + 1} de ${paginas.length}`;
    const ancho = regular.widthOfTextAtSize(limpiar(texto), 7.5);
    p.drawText(limpiar(texto), {
      x: (A4[0] - ancho) / 2,
      y: 28,
      size: 7.5,
      font: regular,
      color: GRIS
    });
  });

  const bytes = await doc.save();
  const buffer = new ArrayBuffer(bytes.byteLength);
  new Uint8Array(buffer).set(bytes);
  return new Blob([buffer], { type: 'application/pdf' });
}
