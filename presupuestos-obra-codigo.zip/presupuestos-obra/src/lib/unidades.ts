import type { Unidad } from '../db';

/** Unidades de medida. La partida a precio cerrado no es una unidad: es un modo de cobro. */
export const UNIDADES: { valor: Unidad; etiqueta: string }[] = [
  { valor: 'm2', etiqueta: 'm²' },
  { valor: 'ml', etiqueta: 'ml' },
  { valor: 'ud', etiqueta: 'ud' },
  { valor: 'h', etiqueta: 'h' },
  { valor: 'kg', etiqueta: 'kg' }
];

export function etiquetaUnidad(unidad: Unidad): string {
  if (unidad === 'global') return 'partida';
  return UNIDADES.find((u) => u.valor === unidad)?.etiqueta ?? unidad;
}

export type ModoCobro = 'entera' | 'medida';

export const MODOS: { valor: ModoCobro; etiqueta: string }[] = [
  { valor: 'entera', etiqueta: 'Partida entera' },
  { valor: 'medida', etiqueta: 'Por medida' }
];

/** Se cobra un precio cerrado por el trabajo, sin metros ni cantidades. */
export function esPrecioCerrado(unidad: Unidad): boolean {
  return unidad === 'global';
}

export const TIPOS: { valor: 'material' | 'mano_obra' | 'mixto'; etiqueta: string }[] = [
  { valor: 'material', etiqueta: 'Material' },
  { valor: 'mano_obra', etiqueta: 'Mano de obra' },
  { valor: 'mixto', etiqueta: 'Todo incluido' }
];
