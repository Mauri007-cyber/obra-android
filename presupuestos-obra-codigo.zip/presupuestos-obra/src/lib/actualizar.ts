import { registerSW } from 'virtual:pwa-register';

/**
 * Actualizaciones silenciosas, pero solo cuando no hay nada a medias.
 *
 * - Comprueba al abrir la app, al recuperar conexión, al volver a primer plano
 *   y cada media hora.
 * - No activa la versión nueva mientras haya una ventana abierta (partida,
 *   precio, vista previa) ni el cursor en un campo: espera a que termine.
 * - Antes de recargar avisa al editor para que guarde lo pendiente.
 * - La versión nueva se activa solo en el momento de recargar, para que la
 *   pantalla que está abierta no pida ficheros de la versión anterior.
 */

let registro: ServiceWorkerRegistration | undefined;
let aplicarVersionNueva: ((recargar?: boolean) => Promise<void>) | undefined;
let hayVersionNueva = false;
let aplicando = false;
let empezado = false;

/** ¿Se perdería algo si recargamos ahora mismo? */
function algoEnUso(): boolean {
  if (document.visibilityState === 'hidden') return false;
  const activo = document.activeElement;
  const escribiendo =
    activo instanceof HTMLInputElement ||
    activo instanceof HTMLTextAreaElement ||
    (activo instanceof HTMLElement && activo.isContentEditable);
  return escribiendo || document.querySelector('[data-en-uso]') !== null;
}

async function aplicarSiSePuede(): Promise<void> {
  if (!hayVersionNueva || aplicando || !aplicarVersionNueva) return;
  if (algoEnUso()) return;

  aplicando = true;
  window.dispatchEvent(new Event('presupuestos:guardar-ya'));
  await new Promise((listo) => window.setTimeout(listo, 400));

  try {
    await aplicarVersionNueva(false);
  } catch {
    aplicando = false;
    return;
  }

  // Si el navegador no llega a cambiar el control, se reintenta más tarde.
  window.setTimeout(() => {
    aplicando = false;
  }, 10_000);
}

function comprobar(): void {
  if (!registro) return;
  registro.update().catch(() => {
    // Sin conexión o servidor caído: se reintenta en la siguiente comprobación.
  });
}

export function vigilarActualizaciones(): void {
  if (empezado || !('serviceWorker' in navigator)) return;
  empezado = true;

  aplicarVersionNueva = registerSW({
    immediate: true,
    onRegisteredSW(_url, registration) {
      registro = registration ?? undefined;
      comprobar();
    },
    onNeedRefresh() {
      hayVersionNueva = true;
      void aplicarSiSePuede();
    }
  });

  navigator.serviceWorker.addEventListener('controllerchange', () => {
    if (aplicando) window.location.reload();
  });

  window.addEventListener('online', comprobar);

  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') comprobar();
    else void aplicarSiSePuede();
  });

  window.setInterval(() => {
    if (document.visibilityState === 'visible') comprobar();
  }, 30 * 60 * 1000);

  window.setInterval(() => {
    if (hayVersionNueva && !aplicando) void aplicarSiSePuede();
  }, 60 * 1000);
}
