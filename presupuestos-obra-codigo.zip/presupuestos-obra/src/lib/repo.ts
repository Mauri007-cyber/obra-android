import { useLiveQuery } from 'dexie-react-hooks';
import {
  db,
  type Ajustes,
  type Linea,
  type Presupuesto,
  type Precio,
  type TipoPartida,
  type Unidad
} from '../db';
import { nuevoId } from './ids';
import { normalizar } from './formato';

const AJUSTES_POR_DEFECTO: Ajustes = {
  id: 'unico',
  nombre: '',
  oficio: 'Albañilería',
  telefono: '',
  validezDias: 30,
  serie: String(new Date().getFullYear()),
  siguienteNumero: 1
};

export async function asegurarAjustes(): Promise<Ajustes> {
  const actual = await db.ajustes.get('unico');
  if (actual) return actual;
  try {
    await db.ajustes.add({ ...AJUSTES_POR_DEFECTO });
  } catch {
    // Otra pestaña los ha creado a la vez.
  }
  return (await db.ajustes.get('unico')) ?? { ...AJUSTES_POR_DEFECTO };
}

export function useAjustes(): Ajustes | undefined {
  return useLiveQuery(() => db.ajustes.get('unico'), []);
}

export function usePresupuestos(): Presupuesto[] | undefined {
  return useLiveQuery(() => db.presupuestos.orderBy('fecha').reverse().toArray(), []);
}

export function usePresupuesto(id: string): Presupuesto | undefined {
  return useLiveQuery(() => db.presupuestos.get(id), [id]);
}

export function usePrecios(): Precio[] | undefined {
  return useLiveQuery(() => db.precios.orderBy('vecesUsado').reverse().toArray(), []);
}

export async function crearPresupuesto(): Promise<Presupuesto> {
  const ajustes = await asegurarAjustes();
  return db.transaction('rw', db.ajustes, db.presupuestos, async () => {
    const numero = `${ajustes.serie}-${String(ajustes.siguienteNumero).padStart(3, '0')}`;
    await db.ajustes.update('unico', { siguienteNumero: ajustes.siguienteNumero + 1 });
    const ahora = new Date().toISOString();
    const presupuesto: Presupuesto = {
      id: nuevoId(),
      numero,
      clienteNombre: '',
      obraTitulo: '',
      fecha: ahora,
      validezDias: ajustes.validezDias,
      estado: 'borrador',
      lineas: [],
      creadoEn: ahora,
      actualizadoEn: ahora
    };
    await db.presupuestos.add(presupuesto);
    return presupuesto;
  });
}

export async function guardarPresupuesto(presupuesto: Presupuesto): Promise<void> {
  await db.presupuestos.put({ ...presupuesto, actualizadoEn: new Date().toISOString() });
}

export async function borrarPresupuesto(id: string): Promise<void> {
  await db.presupuestos.delete(id);
}

export async function restaurarPresupuesto(presupuesto: Presupuesto): Promise<void> {
  await db.presupuestos.put(presupuesto);
}

export async function recordarPrecio(linea: Linea): Promise<void> {
  const concepto = linea.concepto.trim();
  if (!concepto) return;
  const existentes = await db.precios.toArray();
  const igual = existentes.find(
    (p) => normalizar(p.concepto) === normalizar(concepto) && p.unidad === linea.unidad
  );
  const ahora = new Date().toISOString();
  if (igual) {
    await db.precios.put({
      ...igual,
      precioUnitario: linea.precioUnitario,
      tipo: linea.tipo,
      vecesUsado: igual.vecesUsado + 1,
      ultimaVez: ahora
    });
    return;
  }
  await db.precios.add({
    id: nuevoId(),
    concepto,
    unidad: linea.unidad,
    precioUnitario: linea.precioUnitario,
    tipo: linea.tipo,
    vecesUsado: 1,
    ultimaVez: ahora
  });
}

export async function usarPrecio(precioId: string | undefined): Promise<void> {
  if (!precioId) return;
  const precio = await db.precios.get(precioId);
  if (!precio) return;
  await db.precios.put({
    ...precio,
    vecesUsado: precio.vecesUsado + 1,
    ultimaVez: new Date().toISOString()
  });
}

export async function crearPrecio(datos: {
  concepto: string;
  unidad: Unidad;
  precioUnitario: number;
  tipo: TipoPartida;
}): Promise<void> {
  const concepto = datos.concepto.trim();
  if (!concepto) return;
  await db.precios.add({
    id: nuevoId(),
    concepto,
    unidad: datos.unidad,
    precioUnitario: datos.precioUnitario,
    tipo: datos.tipo,
    vecesUsado: 0,
    ultimaVez: new Date().toISOString()
  });
}

export async function actualizarPrecio(precio: Precio): Promise<void> {
  await db.precios.put(precio);
}

export async function restaurarPrecio(precio: Precio): Promise<void> {
  await db.precios.put(precio);
}

export async function borrarPrecio(id: string): Promise<void> {
  await db.precios.delete(id);
}

export async function guardarAjustes(cambios: Partial<Omit<Ajustes, 'id'>>): Promise<void> {
  await asegurarAjustes();
  await db.ajustes.update('unico', cambios);
}

export async function marcarCopia(): Promise<void> {
  await guardarAjustes({ ultimaCopia: new Date().toISOString() });
}
