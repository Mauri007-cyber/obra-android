/**
 * Convierte las páginas de un PDF en imágenes para verlo dentro de la app.
 * pdf.js se carga solo desde aquí: no pesa en el arranque ni al enviar.
 */
export async function paginasDelPdf(blob: Blob): Promise<string[]> {
  const { getDocument, GlobalWorkerOptions } = await import('pdfjs-dist');
  const trabajador = (await import('pdfjs-dist/build/pdf.worker.min.mjs?url')).default;
  GlobalWorkerOptions.workerSrc = trabajador;

  const datos = new Uint8Array(await blob.arrayBuffer());
  const tarea = getDocument({ data: datos });
  const documento = await tarea.promise;

  try {
    const paginas: string[] = [];
    const escala = Math.min(2, Math.max(1.4, window.devicePixelRatio || 1));

    for (let numero = 1; numero <= documento.numPages; numero += 1) {
      const pagina = await documento.getPage(numero);
      const vista = pagina.getViewport({ scale: escala });
      const lienzo = document.createElement('canvas');
      lienzo.width = Math.floor(vista.width);
      lienzo.height = Math.floor(vista.height);
      await pagina.render({ canvas: lienzo, viewport: vista }).promise;
      paginas.push(lienzo.toDataURL('image/jpeg', 0.92));
      pagina.cleanup();
    }

    return paginas;
  } finally {
    await tarea.destroy();
  }
}
