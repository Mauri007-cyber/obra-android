type ResultadoCompartir = 'compartido' | 'descargado' | 'cancelado';

type NavegadorConCompartir = {
  canShare?: (datos: ShareData) => boolean;
  share?: (datos: ShareData) => Promise<void>;
};

export function descargar(blob: Blob, nombre: string): void {
  const url = URL.createObjectURL(blob);
  const enlace = document.createElement('a');
  enlace.href = url;
  enlace.download = nombre;
  document.body.appendChild(enlace);
  enlace.click();
  enlace.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 5000);
}

export async function compartirArchivo(blob: Blob, nombre: string): Promise<ResultadoCompartir> {
  const navegador = navigator as unknown as NavegadorConCompartir;
  const archivo = new File([blob], nombre, { type: blob.type });

  if (navegador.share && navegador.canShare?.({ files: [archivo] })) {
    try {
      await navegador.share({ files: [archivo], title: nombre });
      return 'compartido';
    } catch (error) {
      if ((error as Error)?.name === 'AbortError') return 'cancelado';
    }
  }

  descargar(blob, nombre);
  return 'descargado';
}
