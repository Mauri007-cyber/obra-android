import { describe, expect, it } from 'vitest';
import { subtotalLinea, totalPresupuesto } from './calculos';
import { parsearNumero } from './formato';

describe('subtotalLinea', () => {
  it('multiplica cantidad por precio', () => {
    expect(subtotalLinea({ cantidad: 25, precioUnitario: 18 })).toBe(450);
  });

  it('admite cantidades decimales', () => {
    expect(subtotalLinea({ cantidad: 2.5, precioUnitario: 12.4 })).toBe(31);
  });

  it('redondea a céntimos', () => {
    expect(subtotalLinea({ cantidad: 3, precioUnitario: 0.333 })).toBe(1);
  });

  it('tolera valores no numéricos', () => {
    expect(subtotalLinea({ cantidad: Number.NaN, precioUnitario: 10 })).toBe(0);
  });

  it('una partida entera vale su precio cerrado', () => {
    expect(subtotalLinea({ cantidad: 1, precioUnitario: 1000 })).toBe(1000);
  });
});

describe('totalPresupuesto', () => {
  it('suma las partidas', () => {
    expect(
      totalPresupuesto([
        { cantidad: 25, precioUnitario: 18 },
        { cantidad: 1, precioUnitario: 180 }
      ])
    ).toBe(630);
  });

  it('vale cero sin partidas', () => {
    expect(totalPresupuesto([])).toBe(0);
  });

  it('coincide con la suma de los importes mostrados', () => {
    const lineas = [
      { cantidad: 1, precioUnitario: 0.1 },
      { cantidad: 1, precioUnitario: 0.2 }
    ];
    expect(totalPresupuesto(lineas)).toBe(0.3);
  });

  it('suma precios con céntimos sin descuadrar', () => {
    const lineas = [
      { cantidad: 7, precioUnitario: 12.35 },
      { cantidad: 3, precioUnitario: 4.99 },
      { cantidad: 1.5, precioUnitario: 33.33 }
    ];
    const suma = lineas.reduce((acc, l) => acc + subtotalLinea(l), 0);
    expect(totalPresupuesto(lineas)).toBe(Math.round(suma * 100) / 100);
  });
});

describe('parsearNumero', () => {
  it('lee coma decimal', () => {
    expect(parsearNumero('18,5')).toBe(18.5);
  });

  it('lee miles y decimales españoles', () => {
    expect(parsearNumero('1.245,09')).toBe(1245.09);
  });

  it('lee punto decimal de teclado inglés', () => {
    expect(parsearNumero('18.50')).toBe(18.5);
  });

  it('ignora texto y símbolos', () => {
    expect(parsearNumero(' 450 € ')).toBe(450);
  });

  it('devuelve 0 si está vacío', () => {
    expect(parsearNumero('')).toBe(0);
  });
});
