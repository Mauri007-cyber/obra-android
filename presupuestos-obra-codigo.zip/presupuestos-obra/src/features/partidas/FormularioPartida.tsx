import { useState } from 'react';
import type { Linea, Precio, TipoPartida, Unidad } from '../../db';
import { Hoja } from '../../ui/Hoja';
import { Campo } from '../../ui/Campo';
import { CampoNumero } from '../../ui/CampoNumero';
import { Chips } from '../../ui/Chips';
import { Boton } from '../../ui/Boton';
import {
  MODOS,
  TIPOS,
  UNIDADES,
  etiquetaUnidad,
  esPrecioCerrado,
  type ModoCobro
} from '../../lib/unidades';
import { subtotalLinea } from '../../lib/calculos';
import { euros, numero } from '../../lib/formato';
import { nuevoId } from '../../lib/ids';

export function FormularioPartida({
  inicial,
  precios,
  onGuardar,
  onCerrar
}: {
  inicial?: Linea;
  precios: Precio[];
  onGuardar: (linea: Linea, recordar: boolean) => void;
  onCerrar: () => void;
}) {
  const [concepto, setConcepto] = useState(inicial?.concepto ?? '');
  const [modo, setModo] = useState<ModoCobro>(
    inicial ? (esPrecioCerrado(inicial.unidad) ? 'entera' : 'medida') : 'entera'
  );
  const [cantidad, setCantidad] = useState(
    inicial && !esPrecioCerrado(inicial.unidad) ? inicial.cantidad : 1
  );
  const [unidad, setUnidad] = useState<Unidad>(
    inicial && !esPrecioCerrado(inicial.unidad) ? inicial.unidad : 'm2'
  );
  const [precio, setPrecio] = useState(inicial?.precioUnitario ?? 0);
  const [tipo, setTipo] = useState<TipoPartida>(inicial?.tipo ?? 'mixto');
  const [precioId, setPrecioId] = useState<string | undefined>(inicial?.precioId);
  const [recordar, setRecordar] = useState(!inicial);

  const entera = modo === 'entera';
  const cantidadFinal = entera ? 1 : cantidad;
  const unidadFinal: Unidad = entera ? 'global' : unidad;
  const subtotal = subtotalLinea({ cantidad: cantidadFinal, precioUnitario: precio });
  const puedeGuardar = concepto.trim().length > 0;
  const frecuentes = precios.slice(0, 6);

  function guardar() {
    if (!puedeGuardar) return;
    const linea: Linea = {
      id: inicial?.id ?? nuevoId(),
      concepto: concepto.trim(),
      cantidad: cantidadFinal,
      unidad: unidadFinal,
      precioUnitario: precio,
      tipo
    };
    if (precioId) linea.precioId = precioId;
    onGuardar(linea, recordar);
  }

  function aplicarPrecio(favorito: Precio) {
    setConcepto(favorito.concepto);
    setPrecio(favorito.precioUnitario);
    setTipo(favorito.tipo);
    setPrecioId(favorito.id);
    setRecordar(false);
    if (esPrecioCerrado(favorito.unidad)) {
      setModo('entera');
    } else {
      setModo('medida');
      setUnidad(favorito.unidad);
    }
  }

  return (
    <Hoja
      titulo={inicial ? 'Editar partida' : 'Nueva partida'}
      subtitulo={inicial ? inicial.concepto : undefined}
      onCerrar={onCerrar}
      pie={
        <Boton grande className="w-full" onClick={guardar} disabled={!puedeGuardar}>
          {inicial ? 'Guardar cambios' : 'Añadir partida'}
        </Boton>
      }
    >
      <div className="space-y-5">
        <Campo
          etiqueta="¿Qué es?"
          value={concepto}
          onChange={(evento) => setConcepto(evento.target.value)}
          placeholder="Alicatado del baño"
          autoFocus
          ayuda="Puedes dictarlo con el micrófono del teclado"
        />

        <div>
          <p className="mb-1.5 text-[14px] font-semibold tracking-wide text-suave">
            ¿Cómo lo cobras?
          </p>
          <Chips opciones={MODOS} valor={modo} onCambio={setModo} />
          <p className="mt-1.5 text-[13px] leading-snug text-suave">
            {entera
              ? 'Un precio cerrado por el trabajo: alicatar el baño, 1.000 €.'
              : 'Por metros, horas o kilos: 25 m² a 18 €/m².'}
          </p>
        </div>

        {entera ? (
          <CampoNumero
            etiqueta="Precio de la partida"
            valor={precio}
            onChange={setPrecio}
            sufijo="€"
            ayuda="Con material y mano de obra incluidos. Sin metros ni cantidades."
          />
        ) : (
          <>
            <div className="grid grid-cols-2 gap-3">
              <CampoNumero etiqueta="Cantidad" valor={cantidad} onChange={setCantidad} />
              <CampoNumero
                etiqueta="Precio"
                valor={precio}
                onChange={setPrecio}
                sufijo={`€/${etiquetaUnidad(unidad)}`}
              />
            </div>

            <div>
              <p className="mb-1.5 text-[14px] font-semibold tracking-wide text-suave">Unidad</p>
              <Chips opciones={UNIDADES} valor={unidad} onCambio={setUnidad} />
            </div>
          </>
        )}

        <div className="rounded-2xl bg-acento-claro px-4 py-3">
          <p className="text-[12px] font-bold uppercase tracking-wider text-acento">Va a salir</p>
          <p className="tabular text-[28px] font-bold leading-tight text-acento">
            {euros(subtotal)}
          </p>
          <p className="tabular text-[13px] text-acento/80">
            {entera
              ? 'Precio cerrado, todo incluido'
              : `${numero(cantidad)} ${etiquetaUnidad(unidad)} × ${euros(precio)}`}
          </p>
        </div>

        <div>
          <p className="mb-1.5 text-[14px] font-semibold tracking-wide text-suave">
            ¿Qué incluye?
          </p>
          <Chips opciones={TIPOS} valor={tipo} onCambio={setTipo} />
        </div>

        {frecuentes.length > 0 ? (
          <div>
            <p className="mb-2 text-[14px] font-semibold tracking-wide text-suave">
              Mis precios
            </p>
            <div className="flex flex-wrap gap-2">
              {frecuentes.map((favorito) => (
                <button
                  key={favorito.id}
                  type="button"
                  onClick={() => aplicarPrecio(favorito)}
                  className="h-12 max-w-full rounded-2xl border border-linea bg-white px-3 text-left text-[14px] font-semibold active:bg-papel"
                >
                  <span className="block truncate">{favorito.concepto}</span>
                  <span className="tabular block text-[12px] font-normal text-suave">
                    {esPrecioCerrado(favorito.unidad)
                      ? `${euros(favorito.precioUnitario)} · partida entera`
                      : `${euros(favorito.precioUnitario)}/${etiquetaUnidad(favorito.unidad)}`}
                  </span>
                </button>
              ))}
            </div>
          </div>
        ) : null}

        <label className="flex items-start gap-3 rounded-2xl border border-linea bg-white p-4">
          <input
            type="checkbox"
            checked={recordar}
            onChange={(evento) => setRecordar(evento.target.checked)}
            className="mt-0.5 h-6 w-6 accent-acento"
          />
          <span>
            <span className="block text-[16px] font-semibold">Guardar en «Mis precios»</span>
            <span className="block text-[13px] leading-snug text-suave">
              La próxima vez la añades con un toque.
            </span>
          </span>
        </label>
      </div>
    </Hoja>
  );
}
