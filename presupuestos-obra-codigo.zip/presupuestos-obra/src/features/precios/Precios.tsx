import { useMemo, useState } from 'react';
import type { Precio, TipoPartida, Unidad } from '../../db';
import {
  actualizarPrecio,
  borrarPrecio,
  crearPrecio,
  restaurarPrecio,
  usePrecios
} from '../../lib/repo';
import { euros, normalizar } from '../../lib/formato';
import {
  MODOS,
  TIPOS,
  UNIDADES,
  etiquetaUnidad,
  esPrecioCerrado,
  type ModoCobro
} from '../../lib/unidades';
import { Boton } from '../../ui/Boton';
import { Campo } from '../../ui/Campo';
import { CampoNumero } from '../../ui/CampoNumero';
import { Chips } from '../../ui/Chips';
import { Hoja } from '../../ui/Hoja';
import { useAviso } from '../../ui/aviso';
import { IconoBasura, IconoEtiqueta, IconoLupa, IconoMas } from '../../ui/Iconos';

interface DatosPrecio {
  concepto: string;
  unidad: Unidad;
  precioUnitario: number;
  tipo: TipoPartida;
}

function FormularioPrecio({
  inicial,
  onGuardar,
  onCerrar
}: {
  inicial?: Precio;
  onGuardar: (datos: DatosPrecio) => void;
  onCerrar: () => void;
}) {
  const [concepto, setConcepto] = useState(inicial?.concepto ?? '');
  const [unidad, setUnidad] = useState<Unidad>(inicial?.unidad ?? 'm2');
  const [precio, setPrecio] = useState(inicial?.precioUnitario ?? 0);
  const [tipo, setTipo] = useState<TipoPartida>(inicial?.tipo ?? 'mixto');
  const [modo, setModo] = useState<ModoCobro>(
    inicial ? (esPrecioCerrado(inicial.unidad) ? 'entera' : 'medida') : 'entera'
  );

  return (
    <Hoja
      titulo={inicial ? 'Editar precio' : 'Nuevo precio'}
      onCerrar={onCerrar}
      pie={
        <Boton
          grande
          className="w-full"
          disabled={!concepto.trim()}
          onClick={() =>
            onGuardar({
              concepto: concepto.trim(),
              unidad: modo === 'entera' ? 'global' : unidad,
              precioUnitario: precio,
              tipo
            })
          }
        >
          Guardar
        </Boton>
      }
    >
      <div className="space-y-5">
        <Campo
          etiqueta="¿Qué es?"
          value={concepto}
          onChange={(evento) => setConcepto(evento.target.value)}
          placeholder="Alicatado de baño"
          autoFocus
        />

        <div>
          <p className="mb-1.5 text-[14px] font-semibold tracking-wide text-suave">
            ¿Cómo lo cobras?
          </p>
          <Chips opciones={MODOS} valor={modo} onCambio={setModo} />
        </div>

        {modo === 'entera' ? (
          <CampoNumero
            etiqueta="Precio de la partida"
            valor={precio}
            onChange={setPrecio}
            sufijo="€"
            ayuda="Precio cerrado, sin metros ni cantidades."
          />
        ) : (
          <>
            <CampoNumero
              etiqueta="Precio"
              valor={precio}
              onChange={setPrecio}
              sufijo={`€/${etiquetaUnidad(unidad)}`}
            />

            <div>
              <p className="mb-1.5 text-[14px] font-semibold tracking-wide text-suave">
                Unidad
              </p>
              <Chips opciones={UNIDADES} valor={unidad} onCambio={setUnidad} />
            </div>
          </>
        )}

        <div>
          <p className="mb-1.5 text-[14px] font-semibold tracking-wide text-suave">
            ¿Qué incluye?
          </p>
          <Chips opciones={TIPOS} valor={tipo} onCambio={setTipo} />
        </div>
      </div>
    </Hoja>
  );
}

export function Precios() {
  const precios = usePrecios();
  const { mostrar } = useAviso();
  const [busqueda, setBusqueda] = useState('');
  const [editando, setEditando] = useState<Precio | 'nuevo' | null>(null);

  const lista = precios ?? [];
  const filtrados = useMemo(() => {
    const consulta = normalizar(busqueda);
    if (!consulta) return lista;
    return lista.filter((precio) => normalizar(precio.concepto).includes(consulta));
  }, [lista, busqueda]);

  async function borrar(precio: Precio) {
    await borrarPrecio(precio.id);
    mostrar(`«${precio.concepto}» borrado`, {
      etiqueta: 'Deshacer',
      onClick: () => void restaurarPrecio(precio)
    });
  }

  return (
    <div className="px-4 pb-40 pt-6">
      <header className="mb-5">
        <h1 className="text-[30px] font-bold leading-tight tracking-tight">Mis precios</h1>
        <p className="mt-1 text-[15px] text-suave">
          Los que más usas, a un toque cuando haces un presupuesto.
        </p>
      </header>

      <div className="mb-4 flex items-center gap-2 rounded-2xl border border-linea bg-white px-4">
        <IconoLupa className="h-5 w-5 shrink-0 text-suave" />
        <input
          value={busqueda}
          onChange={(evento) => setBusqueda(evento.target.value)}
          placeholder="Buscar precio"
          className="h-14 w-full bg-transparent text-[17px] outline-none placeholder:text-suave/50"
        />
      </div>

      {precios === undefined ? (
        <p className="py-10 text-center text-[15px] text-suave">Cargando…</p>
      ) : lista.length === 0 ? (
        <div className="rounded-3xl border border-linea bg-white px-6 py-12 text-center">
          <IconoEtiqueta className="mx-auto h-10 w-10 text-suave/50" />
          <p className="mt-3 text-[18px] font-bold">Todavía no hay precios</p>
          <p className="mx-auto mt-1 max-w-[18rem] text-[15px] leading-snug text-suave">
            Se guardan solos cuando añades una partida y marcas «Guardar en Mis precios».
          </p>
        </div>
      ) : filtrados.length === 0 ? (
        <p className="py-10 text-center text-[15px] text-suave">No hay ningún precio con ese nombre.</p>
      ) : (
        <div className="overflow-hidden rounded-3xl border border-linea bg-white">
          {filtrados.map((precio) => (
            <div
              key={precio.id}
              className="flex items-center gap-1 border-b border-linea px-4 last:border-0"
            >
              <button
                type="button"
                onClick={() => setEditando(precio)}
                className="min-w-0 flex-1 py-3.5 text-left"
              >
                <p className="truncate text-[16px] font-semibold">{precio.concepto}</p>
                <p className="text-[13px] text-suave">
                  {esPrecioCerrado(precio.unidad)
                    ? `${euros(precio.precioUnitario)} · partida entera`
                    : `${euros(precio.precioUnitario)} / ${etiquetaUnidad(precio.unidad)}`}
                  {precio.vecesUsado > 0 ? ` · usado ${precio.vecesUsado} ${precio.vecesUsado === 1 ? 'vez' : 'veces'}` : ''}
                </p>
              </button>
              <button
                type="button"
                aria-label={`Borrar ${precio.concepto}`}
                onClick={() => void borrar(precio)}
                className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl text-suave active:bg-black/5"
              >
                <IconoBasura />
              </button>
            </div>
          ))}
        </div>
      )}

      <div className="fixed inset-x-0 bottom-[calc(4.5rem+env(safe-area-inset-bottom))] z-20 mx-auto max-w-md px-4">
        <Boton grande className="w-full shadow-lg" onClick={() => setEditando('nuevo')}>
          <IconoMas className="h-6 w-6" />
          Añadir precio
        </Boton>
      </div>

      {editando ? (
        <FormularioPrecio
          inicial={editando === 'nuevo' ? undefined : editando}
          onCerrar={() => setEditando(null)}
          onGuardar={(datos) => {
            if (editando !== 'nuevo') {
              void actualizarPrecio({ ...editando, ...datos });
            } else {
              void crearPrecio(datos);
            }
            setEditando(null);
          }}
        />
      ) : null}
    </div>
  );
}
