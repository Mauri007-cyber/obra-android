import { Boton } from '../../ui/Boton';
import { IconoFlecha } from '../../ui/Iconos';

export function VistaPrevia({
  titulo,
  paginas,
  error,
  enviando,
  onEnviar,
  onAbrir,
  onCerrar
}: {
  titulo: string;
  paginas: string[];
  error: boolean;
  enviando: boolean;
  onEnviar: () => void;
  onAbrir: () => void;
  onCerrar: () => void;
}) {
  return (
    <div data-en-uso className="fixed inset-0 z-50 flex flex-col bg-tinta">
      <header className="flex items-center gap-2 px-3 py-2 text-white">
        <button
          type="button"
          onClick={onCerrar}
          className="flex h-12 shrink-0 items-center gap-1 rounded-xl px-3 text-[16px] font-semibold active:bg-white/10"
        >
          <IconoFlecha className="h-5 w-5" />
          Volver
        </button>
        <div className="min-w-0 flex-1">
          <p className="truncate text-[16px] font-bold leading-tight">Así va a quedar</p>
          <p className="truncate text-[12px] text-white/70">
            {titulo}
            {paginas.length > 1 ? ` · ${paginas.length} páginas` : ' · 1 página'}
          </p>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto overscroll-contain px-4 pb-6">
        {error ? (
          <div className="mt-10 rounded-3xl bg-white px-6 py-8 text-center">
            <p className="text-[18px] font-bold">No se ha podido mostrar la vista previa</p>
            <p className="mx-auto mt-2 max-w-[20rem] text-[15px] leading-snug text-suave">
              Puedes abrir el PDF aparte para verlo, o enviarlo directamente.
            </p>
            <Boton variante="secundario" className="mt-4 w-full" onClick={onAbrir}>
              Abrir el PDF
            </Boton>
          </div>
        ) : paginas.length === 0 ? (
          <p className="py-16 text-center text-[15px] text-white/80">Preparando las páginas…</p>
        ) : (
          <div className="space-y-4">
            {paginas.map((pagina, indice) => (
              <img
                key={indice}
                src={pagina}
                alt={`Página ${indice + 1} del presupuesto`}
                className="w-full rounded-2xl bg-white shadow-xl"
              />
            ))}
            <p className="pb-2 text-center text-[13px] text-white/70">
              Si algo no cuadra, vuelve y cámbialo antes de enviarlo.
            </p>
          </div>
        )}
      </div>

      <footer
        className="border-t border-white/15 bg-tinta px-4 py-3"
        style={{ paddingBottom: 'calc(0.75rem + env(safe-area-inset-bottom))' }}
      >
        <div className="flex gap-2">
          <Boton variante="secundario" className="flex-1" onClick={onCerrar} disabled={enviando}>
            Volver
          </Boton>
          <Boton grande className="flex-[1.4]" onClick={onEnviar} disabled={enviando}>
            {enviando ? 'Enviando…' : 'Enviar'}
          </Boton>
        </div>
      </footer>
    </div>
  );
}
