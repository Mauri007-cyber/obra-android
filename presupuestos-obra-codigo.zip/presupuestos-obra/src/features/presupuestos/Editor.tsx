import { useEffect, useRef, useState } from 'react';
import type { Linea, Presupuesto } from '../../db';
import {
  borrarPresupuesto,
  guardarPresupuesto,
  recordarPrecio,
  usarPrecio,
  useAjustes,
  usePrecios,
  usePresupuesto
} from '../../lib/repo';
import { euros, numero } from '../../lib/formato';
import { subtotalLinea, totalPresupuesto } from '../../lib/calculos';
import { compartirArchivo } from '../../lib/compartir';
import { etiquetaUnidad, esPrecioCerrado } from '../../lib/unidades';
import { Boton } from '../../ui/Boton';
import { Campo, CampoArea } from '../../ui/Campo';
import { CampoNumero } from '../../ui/CampoNumero';
import { ChipEstado, ESTADOS } from '../../ui/Estado';
import { useAviso } from '../../ui/aviso';
import { IconoBasura, IconoFlecha, IconoMas, IconoMenos } from '../../ui/Iconos';
import { FormularioPartida } from '../partidas/FormularioPartida';
import { VistaPrevia } from './VistaPrevia';

export function Editor({ id, onVolver }: { id: string; onVolver: () => void }) {
  const presupuesto = usePresupuesto(id);

  if (!presupuesto) {
    return (
      <div className="fixed inset-0 z-40 flex items-center justify-center bg-papel text-[15px] text-suave">
        Cargando…
      </div>
    );
  }

  return <Formulario key={presupuesto.id} inicial={presupuesto} onVolver={onVolver} />;
}

function Formulario({ inicial, onVolver }: { inicial: Presupuesto; onVolver: () => void }) {
  const ajustes = useAjustes();
  const precios = usePrecios() ?? [];
  const { mostrar } = useAviso();

  const [p, setP] = useState(inicial);
  const ref = useRef(inicial);
  const temporizador = useRef<number | undefined>(undefined);
  const eliminado = useRef(false);

  const [guardando, setGuardando] = useState(false);
  const [partida, setPartida] = useState<Linea | 'nueva' | null>(null);
  const [verMas, setVerMas] = useState(false);
  const [enviando, setEnviando] = useState(false);
  const [preparandoVista, setPreparandoVista] = useState(false);
  const [vista, setVista] = useState<{
    blob: Blob;
    nombre: string;
    paginas: string[];
    error: boolean;
  } | null>(null);
  const [confirmarBorrado, setConfirmarBorrado] = useState(false);

  function cambiar(cambios: Partial<Presupuesto>) {
    const siguiente = { ...ref.current, ...cambios };
    ref.current = siguiente;
    setP(siguiente);
    setGuardando(true);
    window.clearTimeout(temporizador.current);
    temporizador.current = window.setTimeout(() => {
      void guardarPresupuesto(ref.current).then(() => setGuardando(false));
    }, 350);
  }

  useEffect(() => {
    return () => {
      window.clearTimeout(temporizador.current);
      if (!eliminado.current) void guardarPresupuesto(ref.current);
    };
  }, []);

  // Antes de que la app se actualice y recargue, guardar lo pendiente.
  useEffect(() => {
    const guardarYa = () => {
      window.clearTimeout(temporizador.current);
      if (!eliminado.current) void guardarPresupuesto(ref.current);
    };
    window.addEventListener('presupuestos:guardar-ya', guardarYa);
    return () => window.removeEventListener('presupuestos:guardar-ya', guardarYa);
  }, []);

  async function salir() {
    window.clearTimeout(temporizador.current);
    await guardarPresupuesto(ref.current);
    onVolver();
  }

  async function guardarPartida(linea: Linea, recordar: boolean) {
    const anteriores = ref.current.lineas;
    const existe = anteriores.some((l) => l.id === linea.id);
    cambiar({
      lineas: existe ? anteriores.map((l) => (l.id === linea.id ? linea : l)) : [...anteriores, linea]
    });
    setPartida(null);
    if (recordar) await recordarPrecio(linea);
    if (!existe) await usarPrecio(linea.precioId);
  }

  function borrarPartida(linea: Linea) {
    const anteriores = ref.current.lineas;
    cambiar({ lineas: anteriores.filter((l) => l.id !== linea.id) });
    mostrar('Partida borrada', {
      etiqueta: 'Deshacer',
      onClick: () => cambiar({ lineas: anteriores })
    });
  }

  async function abrirVistaPrevia() {
    const actual = ref.current;
    if (!ajustes) return;
    if (!actual.clienteNombre.trim()) {
      mostrar('Pon el nombre del cliente para poder verlo.');
      return;
    }
    if (actual.lineas.length === 0) {
      mostrar('Añade al menos una partida.');
      return;
    }

    setPreparandoVista(true);
    try {
      window.clearTimeout(temporizador.current);
      await guardarPresupuesto(actual);
      const { generarPdf, nombreArchivo } = await import('../../lib/pdf');
      const pdf = await generarPdf(actual, ajustes);

      let paginas: string[] = [];
      let fallo = false;
      try {
        const { paginasDelPdf } = await import('../../lib/vistaPrevia');
        paginas = await paginasDelPdf(pdf);
      } catch (error) {
        console.error(error);
        fallo = true;
      }

      setVista({ blob: pdf, nombre: nombreArchivo(actual), paginas, error: fallo });
    } catch (error) {
      console.error(error);
      mostrar('No se ha podido preparar el PDF. Prueba otra vez.');
    } finally {
      setPreparandoVista(false);
    }
  }

  async function enviarDesdeVista() {
    if (!vista) return;
    setEnviando(true);
    try {
      const resultado = await compartirArchivo(vista.blob, vista.nombre);

      if (resultado === 'cancelado') {
        mostrar('No se ha enviado.');
        return;
      }

      cambiar({
        estado: ref.current.estado === 'borrador' ? 'enviado' : ref.current.estado,
        enviadoEn: new Date().toISOString()
      });
      setVista(null);
      mostrar(
        resultado === 'compartido'
          ? 'Presupuesto enviado.'
          : 'PDF descargado. Ya puedes mandarlo por WhatsApp.'
      );
    } catch (error) {
      console.error(error);
      mostrar('No se ha podido enviar el PDF. Prueba otra vez.');
    } finally {
      setEnviando(false);
    }
  }

  function abrirPdfFuera() {
    if (!vista) return;
    const url = URL.createObjectURL(vista.blob);
    window.open(url, '_blank', 'noopener');
    window.setTimeout(() => URL.revokeObjectURL(url), 60_000);
  }

  async function eliminar() {
    eliminado.current = true;
    window.clearTimeout(temporizador.current);
    await borrarPresupuesto(ref.current.id);
    mostrar('Presupuesto borrado.');
    onVolver();
  }

  const total = totalPresupuesto(p.lineas);

  return (
    <div className="fixed inset-0 z-40 flex flex-col bg-papel">
      <header className="flex items-center gap-2 border-b border-linea bg-white px-2 py-2">
        <button
          type="button"
          onClick={() => void salir()}
          className="-ml-1 flex h-12 shrink-0 items-center gap-1 rounded-xl px-3 text-[16px] font-semibold text-acento active:bg-acento/5"
        >
          <IconoFlecha className="h-5 w-5" />
          Volver
        </button>
        <div className="min-w-0 flex-1">
          <p className="truncate text-[16px] font-bold leading-tight">{p.numero}</p>
          <p className="text-[12px] text-suave">{guardando ? 'Guardando…' : 'Guardado'}</p>
        </div>
        <ChipEstado estado={p.estado} />
      </header>

      <div className="flex-1 overflow-y-auto overscroll-contain px-4 pb-6 pt-4">
        <section className="rounded-3xl border border-linea bg-white p-4">
          <Campo
            etiqueta="Cliente"
            value={p.clienteNombre}
            onChange={(evento) => cambiar({ clienteNombre: evento.target.value })}
            placeholder="Nombre del cliente"
          />
          <Campo
            etiqueta="Obra"
            className="mt-4"
            value={p.obraTitulo}
            onChange={(evento) => cambiar({ obraTitulo: evento.target.value })}
            placeholder="Reforma de baño"
          />
          <Campo
            etiqueta="Dirección (opcional)"
            className="mt-4"
            value={p.obraDireccion ?? ''}
            onChange={(evento) => cambiar({ obraDireccion: evento.target.value })}
            placeholder="Calle, número, piso"
          />
        </section>

        <section className="mt-4 overflow-hidden rounded-3xl border border-linea bg-white">
          <header className="flex items-center justify-between px-4 pb-1 pt-4">
            <h2 className="text-[12.5px] font-bold uppercase tracking-wider text-suave">
              Partidas
            </h2>
            <span className="text-[13px] text-suave">{p.lineas.length}</span>
          </header>

          {p.lineas.length === 0 ? (
            <p className="px-4 pb-2 pt-2 text-[15px] leading-snug text-suave">
              Todavía no hay partidas. Añade la primera con el botón de abajo.
            </p>
          ) : (
            <div className="mt-2 px-4">
              {p.lineas.map((linea) => (
                <div
                  key={linea.id}
                  className="flex items-start gap-1 border-b border-linea last:border-0"
                >
                  <button
                    type="button"
                    onClick={() => setPartida(linea)}
                    className="flex min-w-0 flex-1 items-start gap-3 py-3 text-left"
                  >
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[16px] font-semibold">
                        {linea.concepto || 'Partida sin nombre'}
                      </p>
                      <p className="tabular text-[13px] text-suave">
                        {esPrecioCerrado(linea.unidad)
                          ? 'Partida entera'
                          : `${numero(linea.cantidad)} ${etiquetaUnidad(linea.unidad)} × ${euros(linea.precioUnitario)}`}
                      </p>
                    </div>
                    <p className="tabular shrink-0 pt-0.5 text-[16px] font-bold">
                      {euros(subtotalLinea(linea))}
                    </p>
                  </button>
                  <button
                    type="button"
                    aria-label={`Borrar ${linea.concepto}`}
                    onClick={() => borrarPartida(linea)}
                    className="mt-1 flex h-11 w-11 shrink-0 items-center justify-center rounded-xl text-suave active:bg-black/5"
                  >
                    <IconoBasura />
                  </button>
                </div>
              ))}
            </div>
          )}

          <div className="p-3">
            <Boton variante="secundario" className="w-full" onClick={() => setPartida('nueva')}>
              <IconoMas />
              Añadir partida
            </Boton>
          </div>
        </section>

        <section className="mt-4 rounded-3xl border border-linea bg-white p-4">
          <h2 className="text-[12.5px] font-bold uppercase tracking-wider text-suave">Estado</h2>
          <div className="mt-2 flex flex-wrap gap-2">
            {ESTADOS.map((estado) => (
              <button
                key={estado.valor}
                type="button"
                onClick={() => cambiar({ estado: estado.valor })}
                className={`h-11 rounded-full px-4 text-[14px] font-semibold ${
                  p.estado === estado.valor
                    ? `${estado.clase} ring-2 ring-tinta/25`
                    : 'bg-black/5 text-suave'
                }`}
              >
                {estado.etiqueta}
              </button>
            ))}
          </div>
        </section>

        <section className="mt-4 rounded-3xl border border-linea bg-white">
          <button
            type="button"
            onClick={() => setVerMas((valor) => !valor)}
            className="flex w-full items-center justify-between px-4 py-4 text-left text-[16px] font-semibold"
          >
            Más opciones
            <span className="text-suave">
              {verMas ? <IconoMenos /> : <IconoMas />}
            </span>
          </button>

          {verMas ? (
            <div className="space-y-4 border-t border-linea px-4 py-4">
              <CampoNumero
                etiqueta="Validez del presupuesto"
                valor={p.validezDias}
                onChange={(valor) => cambiar({ validezDias: valor })}
                sufijo="días"
              />
              <CampoArea
                etiqueta="Notas para el cliente"
                value={p.notas ?? ''}
                onChange={(evento) => cambiar({ notas: evento.target.value })}
                placeholder="Materiales incluidos, plazos, forma de pago…"
              />
              {confirmarBorrado ? (
                <div className="rounded-2xl bg-mal/5 p-3">
                  <p className="text-[15px] font-semibold text-mal">
                    ¿Borrar el presupuesto {p.numero}?
                  </p>
                  <div className="mt-3 flex gap-2">
                    <Boton variante="peligro" className="flex-1" onClick={() => void eliminar()}>
                      Sí, borrar
                    </Boton>
                    <Boton
                      variante="secundario"
                      className="flex-1"
                      onClick={() => setConfirmarBorrado(false)}
                    >
                      Cancelar
                    </Boton>
                  </div>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => setConfirmarBorrado(true)}
                  className="text-[15px] font-semibold text-mal"
                >
                  Borrar este presupuesto
                </button>
              )}
            </div>
          ) : null}
        </section>
      </div>

      <footer
        className="border-t border-linea bg-white px-4 py-3"
        style={{ paddingBottom: 'calc(0.75rem + env(safe-area-inset-bottom))' }}
      >
        <div className="flex items-center gap-3">
          <div className="min-w-0">
            <p className="text-[11px] font-bold uppercase tracking-wider text-suave">Total</p>
            <p className="tabular truncate text-[24px] font-bold leading-tight">{euros(total)}</p>
          </div>
          <Boton
            grande
            className="flex-1"
            onClick={() => void abrirVistaPrevia()}
            disabled={preparandoVista || !ajustes}
          >
            {preparandoVista ? 'Preparando…' : 'Ver y enviar'}
          </Boton>
        </div>
      </footer>

      {partida ? (
        <FormularioPartida
          inicial={partida === 'nueva' ? undefined : partida}
          precios={precios}
          onGuardar={(linea, recordar) => void guardarPartida(linea, recordar)}
          onCerrar={() => setPartida(null)}
        />
      ) : null}

      {vista ? (
        <VistaPrevia
          titulo={`Presupuesto ${p.numero}`}
          paginas={vista.paginas}
          error={vista.error}
          enviando={enviando}
          onEnviar={() => void enviarDesdeVista()}
          onAbrir={abrirPdfFuera}
          onCerrar={() => setVista(null)}
        />
      ) : null}
    </div>
  );
}
