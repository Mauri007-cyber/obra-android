import { useMemo, useState } from 'react';
import { crearPresupuesto, useAjustes, usePresupuestos } from '../../lib/repo';
import { euros, fecha, normalizar } from '../../lib/formato';
import { totalPresupuesto } from '../../lib/calculos';
import { ChipEstado } from '../../ui/Estado';
import { Boton } from '../../ui/Boton';
import { IconoDocumento, IconoLupa, IconoMas } from '../../ui/Iconos';

function diasDesde(iso?: string): number | null {
  if (!iso) return null;
  const dias = Math.floor((Date.now() - new Date(iso).getTime()) / 86_400_000);
  return Number.isFinite(dias) ? dias : null;
}

export function Lista({
  onAbrir,
  onAjustes
}: {
  onAbrir: (id: string) => void;
  onAjustes: () => void;
}) {
  const presupuestos = usePresupuestos();
  const ajustes = useAjustes();
  const [busqueda, setBusqueda] = useState('');
  const [creando, setCreando] = useState(false);

  const lista = presupuestos ?? [];

  const filtrados = useMemo(() => {
    const consulta = normalizar(busqueda);
    if (!consulta) return lista;
    return lista.filter((presupuesto) =>
      normalizar(
        `${presupuesto.clienteNombre} ${presupuesto.obraTitulo} ${presupuesto.numero}`
      ).includes(consulta)
    );
  }, [lista, busqueda]);

  const sinPerfil = ajustes !== undefined && !ajustes.nombre.trim();
  const diasCopia = diasDesde(ajustes?.ultimaCopia);
  const recordarCopia = lista.length >= 3 && (diasCopia === null || diasCopia > 15);

  async function nuevo() {
    if (creando) return;
    setCreando(true);
    try {
      const presupuesto = await crearPresupuesto();
      onAbrir(presupuesto.id);
    } finally {
      setCreando(false);
    }
  }

  return (
    <div className="px-4 pb-40 pt-6">
      <header className="mb-5">
        <h1 className="text-[30px] font-bold leading-tight tracking-tight">Presupuestos</h1>
        <p className="mt-1 text-[15px] text-suave">
          {lista.length === 0
            ? 'Todo lo que presupuestas, en un sitio.'
            : `${lista.length} presupuesto${lista.length === 1 ? '' : 's'} guardado${lista.length === 1 ? '' : 's'}`}
        </p>
      </header>

      {sinPerfil ? (
        <button
          type="button"
          onClick={onAjustes}
          className="mb-4 w-full rounded-2xl border border-acento/25 bg-acento-claro p-4 text-left"
        >
          <p className="text-[16px] font-bold text-acento">Pon tu nombre y tu teléfono</p>
          <p className="mt-0.5 text-[14px] leading-snug text-acento/85">
            Es lo primero que ve el cliente en el presupuesto. Toca aquí para rellenarlo.
          </p>
        </button>
      ) : null}

      {recordarCopia ? (
        <button
          type="button"
          onClick={onAjustes}
          className="mb-4 w-full rounded-2xl border border-linea bg-white p-4 text-left"
        >
          <p className="text-[15px] font-bold">Guarda una copia de seguridad</p>
          <p className="mt-0.5 text-[14px] leading-snug text-suave">
            {diasCopia === null
              ? 'Todavía no has guardado ninguna copia de tus presupuestos.'
              : `Hace ${diasCopia} días que no guardas una copia.`}
          </p>
        </button>
      ) : null}

      <div className="mb-4">
        <div className="flex items-center gap-2 rounded-2xl border border-linea bg-white px-4">
          <IconoLupa className="h-5 w-5 shrink-0 text-suave" />
          <input
            value={busqueda}
            onChange={(evento) => setBusqueda(evento.target.value)}
            placeholder="Buscar cliente u obra"
            className="h-14 w-full bg-transparent text-[17px] outline-none placeholder:text-suave/50"
          />
          {busqueda ? (
            <button
              type="button"
              onClick={() => setBusqueda('')}
              className="shrink-0 text-[14px] font-semibold text-suave"
            >
              Borrar
            </button>
          ) : null}
        </div>
      </div>

      {presupuestos === undefined ? (
        <p className="py-10 text-center text-[15px] text-suave">Cargando…</p>
      ) : lista.length === 0 ? (
        <div className="rounded-3xl border border-linea bg-white px-6 py-12 text-center">
          <IconoDocumento className="mx-auto h-10 w-10 text-suave/50" />
          <p className="mt-3 text-[18px] font-bold">Todavía no hay presupuestos</p>
          <p className="mx-auto mt-1 max-w-[16rem] text-[15px] leading-snug text-suave">
            Pulsa el botón de abajo para hacer el primero.
          </p>
        </div>
      ) : filtrados.length === 0 ? (
        <p className="py-10 text-center text-[15px] text-suave">
          No hay ningún presupuesto que coincida con «{busqueda}».
        </p>
      ) : (
        <div className="overflow-hidden rounded-3xl border border-linea bg-white">
          {filtrados.map((presupuesto) => (
            <button
              key={presupuesto.id}
              type="button"
              onClick={() => onAbrir(presupuesto.id)}
              className="flex w-full items-start gap-3 border-b border-linea px-4 py-4 text-left last:border-0 active:bg-papel"
            >
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <ChipEstado estado={presupuesto.estado} />
                  <span className="text-[12.5px] text-suave">{fecha(presupuesto.fecha)}</span>
                </div>
                <p className="mt-1.5 truncate text-[17px] font-bold">
                  {presupuesto.clienteNombre || 'Sin cliente'}
                </p>
                <p className="truncate text-[14px] text-suave">
                  {presupuesto.obraTitulo || 'Sin obra'}
                </p>
              </div>
              <div className="shrink-0 text-right">
                <p className="tabular text-[18px] font-bold">
                  {euros(totalPresupuesto(presupuesto.lineas))}
                </p>
                <p className="text-[12px] text-suave">
                  {presupuesto.lineas.length} partida{presupuesto.lineas.length === 1 ? '' : 's'}
                </p>
              </div>
            </button>
          ))}
        </div>
      )}

      <div className="fixed inset-x-0 bottom-[calc(4.5rem+env(safe-area-inset-bottom))] z-20 mx-auto max-w-md px-4">
        <Boton grande className="w-full shadow-lg" onClick={() => void nuevo()} disabled={creando}>
          <IconoMas className="h-6 w-6" />
          {creando ? 'Creando…' : 'Nuevo presupuesto'}
        </Boton>
      </div>
    </div>
  );
}
