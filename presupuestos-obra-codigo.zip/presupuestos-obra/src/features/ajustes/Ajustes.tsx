import { useEffect, useRef, useState, type InputHTMLAttributes } from 'react';
import { guardarAjustes, useAjustes } from '../../lib/repo';
import { exportarCopia, importarCopia } from '../../lib/copia';
import { fecha, parsearNumero } from '../../lib/formato';
import { Boton } from '../../ui/Boton';
import { Campo } from '../../ui/Campo';
import { useAviso } from '../../ui/aviso';

function CampoGuardado({
  etiqueta,
  valor,
  onGuardar,
  ayuda,
  placeholder,
  inputMode
}: {
  etiqueta: string;
  valor: string;
  onGuardar: (valor: string) => void;
  ayuda?: string;
  placeholder?: string;
  inputMode?: InputHTMLAttributes<HTMLInputElement>['inputMode'];
}) {
  const [texto, setTexto] = useState(valor);

  useEffect(() => setTexto(valor), [valor]);

  return (
    <Campo
      etiqueta={etiqueta}
      ayuda={ayuda}
      placeholder={placeholder}
      inputMode={inputMode}
      value={texto}
      onChange={(evento) => setTexto(evento.target.value)}
      onBlur={() => {
        if (texto !== valor) onGuardar(texto);
      }}
    />
  );
}

export function Ajustes() {
  const ajustes = useAjustes();
  const { mostrar } = useAviso();
  const archivo = useRef<HTMLInputElement>(null);
  const [guardandoCopia, setGuardandoCopia] = useState(false);
  const [restaurando, setRestaurando] = useState(false);

  if (!ajustes) {
    return <p className="px-4 py-10 text-[15px] text-suave">Cargando…</p>;
  }

  async function guardarCopia() {
    setGuardandoCopia(true);
    try {
      const resultado = await exportarCopia();
      if (resultado !== 'cancelado') mostrar('Copia de seguridad guardada.');
    } catch {
      mostrar('No se ha podido guardar la copia.');
    } finally {
      setGuardandoCopia(false);
    }
  }

  async function restaurar(textoPlano: string) {
    setRestaurando(true);
    try {
      const resultado = await importarCopia(textoPlano);
      mostrar(
        `Copia restaurada: ${resultado.presupuestos} presupuesto${
          resultado.presupuestos === 1 ? '' : 's'
        } nuevo${resultado.presupuestos === 1 ? '' : 's'}.`
      );
    } catch (error) {
      mostrar(error instanceof Error ? error.message : 'No se ha podido restaurar la copia.');
    } finally {
      setRestaurando(false);
    }
  }

  return (
    <div className="px-4 pb-32 pt-6">
      <header className="mb-5">
        <h1 className="text-[30px] font-bold leading-tight tracking-tight">Ajustes</h1>
        <p className="mt-1 text-[15px] text-suave">Tus datos y la copia de seguridad.</p>
      </header>

      <section className="rounded-3xl border border-linea bg-white p-4">
        <h2 className="mb-3 text-[12.5px] font-bold uppercase tracking-wider text-suave">
          Tus datos
        </h2>
        <div className="space-y-4">
          <CampoGuardado
            etiqueta="Nombre"
            valor={ajustes.nombre}
            placeholder="Antonio García"
            onGuardar={(valor) => void guardarAjustes({ nombre: valor })}
            ayuda="Sale en la cabecera de cada presupuesto."
          />
          <CampoGuardado
            etiqueta="Oficio"
            valor={ajustes.oficio}
            placeholder="Albañilería"
            onGuardar={(valor) => void guardarAjustes({ oficio: valor })}
          />
          <CampoGuardado
            etiqueta="Teléfono"
            valor={ajustes.telefono}
            placeholder="600 000 000"
            inputMode="tel"
            onGuardar={(valor) => void guardarAjustes({ telefono: valor })}
          />
          <CampoGuardado
            etiqueta="NIF (opcional)"
            valor={ajustes.nif ?? ''}
            placeholder="00000000X"
            onGuardar={(valor) => void guardarAjustes({ nif: valor })}
          />
          <CampoGuardado
            etiqueta="Dirección (opcional)"
            valor={ajustes.direccion ?? ''}
            placeholder="Calle, número, localidad"
            onGuardar={(valor) => void guardarAjustes({ direccion: valor })}
          />
        </div>
      </section>

      <section className="mt-4 rounded-3xl border border-linea bg-white p-4">
        <h2 className="mb-3 text-[12.5px] font-bold uppercase tracking-wider text-suave">
          Numeración
        </h2>
        <div className="space-y-4">
          <CampoGuardado
            etiqueta="Año o serie"
            valor={ajustes.serie}
            onGuardar={(valor) => void guardarAjustes({ serie: valor.trim() || ajustes.serie })}
          />
          <CampoGuardado
            etiqueta="Siguiente número"
            valor={String(ajustes.siguienteNumero)}
            inputMode="numeric"
            onGuardar={(valor) =>
              void guardarAjustes({
                siguienteNumero: Math.max(1, Math.round(parsearNumero(valor)))
              })
            }
            ayuda={`El próximo presupuesto será ${ajustes.serie}-${String(
              ajustes.siguienteNumero
            ).padStart(3, '0')}.`}
          />
        </div>
      </section>

      <section className="mt-4 rounded-3xl border border-linea bg-white p-4">
        <h2 className="mb-1 text-[12.5px] font-bold uppercase tracking-wider text-suave">
          Copia de seguridad
        </h2>
        <p className="text-[14px] leading-snug text-suave">
          {ajustes.ultimaCopia
            ? `Última copia: ${fecha(ajustes.ultimaCopia)}.`
            : 'Todavía no has guardado ninguna copia.'}
        </p>
        <p className="mt-2 rounded-2xl bg-papel px-3 py-2.5 text-[13.5px] leading-snug text-suave">
          Tus presupuestos están guardados en este móvil. Guarda una copia de vez en cuando y
          envíatela a ti mismo por WhatsApp.
        </p>

        <div className="mt-4 space-y-2">
          <Boton
            variante="secundario"
            className="w-full"
            onClick={() => void guardarCopia()}
            disabled={guardandoCopia}
          >
            {guardandoCopia ? 'Preparando…' : 'Guardar una copia'}
          </Boton>
          <Boton
            variante="secundario"
            className="w-full"
            onClick={() => archivo.current?.click()}
            disabled={restaurando}
          >
            {restaurando ? 'Restaurando…' : 'Restaurar desde una copia'}
          </Boton>
          <input
            ref={archivo}
            type="file"
            accept="application/json,.json"
            className="hidden"
            onChange={(evento) => {
              const seleccionado = evento.target.files?.[0];
              evento.target.value = '';
              if (!seleccionado) return;
              void seleccionado
                .text()
                .then((texto) => restaurar(texto))
                .catch(() => mostrar('No se ha podido leer el archivo.'));
            }}
          />
        </div>
      </section>

      <section className="mt-4 rounded-3xl border border-linea bg-white p-4">
        <h2 className="mb-2 text-[12.5px] font-bold uppercase tracking-wider text-suave">
          Tenerla como una app
        </h2>
        <p className="text-[14px] leading-snug text-suave">
          Abre el menú del navegador (los tres puntos) y elige «Añadir a pantalla de inicio».
          Así se abre como cualquier otra aplicación, sin buscar la dirección.
        </p>
      </section>

      <p className="mt-6 text-center text-[12.5px] leading-snug text-suave">
        Presupuestos de obra · funciona sin conexión
      </p>
    </div>
  );
}
