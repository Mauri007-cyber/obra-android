import { useEffect, useState } from 'react';
import { aTexto, parsearNumero } from '../lib/formato';
import { Campo } from './Campo';

export function CampoNumero({
  etiqueta,
  valor,
  onChange,
  sufijo,
  ayuda,
  autoFocus
}: {
  etiqueta: string;
  valor: number;
  onChange: (valor: number) => void;
  sufijo?: string;
  ayuda?: string;
  autoFocus?: boolean;
}) {
  const [texto, setTexto] = useState(() => aTexto(valor));
  const [enfocado, setEnfocado] = useState(false);

  useEffect(() => {
    if (!enfocado) setTexto(aTexto(valor));
  }, [valor, enfocado]);

  return (
    <Campo
      etiqueta={etiqueta}
      sufijo={sufijo}
      ayuda={ayuda}
      autoFocus={autoFocus}
      inputMode="decimal"
      value={texto}
      onFocus={() => setEnfocado(true)}
      onChange={(evento) => {
        setTexto(evento.target.value);
        onChange(parsearNumero(evento.target.value));
      }}
      onBlur={() => {
        setEnfocado(false);
        setTexto(aTexto(parsearNumero(texto)));
      }}
    />
  );
}
