export function Chips<T extends string>({
  opciones,
  valor,
  onCambio
}: {
  opciones: { valor: T; etiqueta: string }[];
  valor: T;
  onCambio: (valor: T) => void;
}) {
  return (
    <div className="flex flex-wrap gap-2">
      {opciones.map((opcion) => (
        <button
          key={opcion.valor}
          type="button"
          aria-pressed={valor === opcion.valor}
          onClick={() => onCambio(opcion.valor)}
          className={`h-12 rounded-2xl px-4 text-[15px] font-semibold transition-colors ${
            valor === opcion.valor
              ? 'bg-tinta text-white'
              : 'border border-linea bg-white text-tinta'
          }`}
        >
          {opcion.etiqueta}
        </button>
      ))}
    </div>
  );
}
