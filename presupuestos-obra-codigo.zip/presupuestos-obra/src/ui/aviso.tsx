import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
  type ReactNode
} from 'react';

interface Accion {
  etiqueta: string;
  onClick: () => void;
}

interface Aviso {
  id: number;
  texto: string;
  accion?: Accion;
}

interface ContextoAviso {
  mostrar: (texto: string, accion?: Accion) => void;
}

const Contexto = createContext<ContextoAviso>({ mostrar: () => undefined });

export function useAviso(): ContextoAviso {
  return useContext(Contexto);
}

export function ProveedorAviso({ children }: { children: ReactNode }) {
  const [aviso, setAviso] = useState<Aviso | null>(null);
  const temporizador = useRef<number | undefined>(undefined);

  const mostrar = useCallback((texto: string, accion?: Accion) => {
    window.clearTimeout(temporizador.current);
    setAviso({ id: Date.now(), texto, accion });
    temporizador.current = window.setTimeout(() => setAviso(null), accion ? 8000 : 3500);
  }, []);

  useEffect(() => () => window.clearTimeout(temporizador.current), []);

  return (
    <Contexto.Provider value={{ mostrar }}>
      {children}
      <div className="pointer-events-none fixed inset-x-0 bottom-0 z-50 flex justify-center px-4 pb-[calc(6rem+env(safe-area-inset-bottom))]">
        {aviso ? (
          <div
            key={aviso.id}
            className="pointer-events-auto flex w-full max-w-md items-center gap-3 rounded-2xl bg-tinta px-4 py-3 text-white shadow-xl"
          >
            <p className="flex-1 text-[15px] leading-snug">{aviso.texto}</p>
            {aviso.accion ? (
              <button
                type="button"
                onClick={() => {
                  aviso.accion?.onClick();
                  setAviso(null);
                }}
                className="shrink-0 rounded-xl px-3 py-2 text-[15px] font-bold text-[#f0b27a]"
              >
                {aviso.accion.etiqueta}
              </button>
            ) : null}
          </div>
        ) : null}
      </div>
    </Contexto.Provider>
  );
}
