import type { Estado } from '../db';

export const ESTADOS: { valor: Estado; etiqueta: string; clase: string }[] = [
  { valor: 'borrador', etiqueta: 'Borrador', clase: 'bg-black/5 text-suave' },
  { valor: 'enviado', etiqueta: 'Enviado', clase: 'bg-info/10 text-info' },
  { valor: 'aceptado', etiqueta: 'Aceptado', clase: 'bg-ok/10 text-ok' },
  { valor: 'rechazado', etiqueta: 'Rechazado', clase: 'bg-mal/10 text-mal' },
  { valor: 'terminado', etiqueta: 'Terminado', clase: 'bg-tinta text-white' }
];

export function ChipEstado({ estado, grande = false }: { estado: Estado; grande?: boolean }) {
  const datos = ESTADOS.find((e) => e.valor === estado) ?? ESTADOS[0];
  return (
    <span
      className={`inline-flex items-center rounded-full font-bold uppercase tracking-wide ${
        grande ? 'px-3 py-1.5 text-[12px]' : 'px-2 py-0.5 text-[10.5px]'
      } ${datos.clase}`}
    >
      {datos.etiqueta}
    </span>
  );
}
