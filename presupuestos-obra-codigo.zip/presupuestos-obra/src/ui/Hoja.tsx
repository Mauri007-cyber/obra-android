import type { ReactNode } from 'react';
import { IconoFlecha } from './Iconos';

export function Hoja({
  titulo,
  subtitulo,
  onCerrar,
  children,
  pie
}: {
  titulo: string;
  subtitulo?: string;
  onCerrar: () => void;
  children: ReactNode;
  pie?: ReactNode;
}) {
  return (
    <div data-en-uso className="fixed inset-0 z-40 flex flex-col bg-papel">
      <header className="flex items-start gap-2 border-b border-linea bg-white px-2 py-2">
        <button
          type="button"
          onClick={onCerrar}
          className="-ml-1 flex h-12 shrink-0 items-center gap-1 rounded-xl px-3 text-[16px] font-semibold text-acento active:bg-acento/5"
        >
          <IconoFlecha className="h-5 w-5" />
          Volver
        </button>
        <div className="min-w-0 flex-1 py-1 pr-2">
          <h1 className="truncate text-[18px] font-bold leading-tight">{titulo}</h1>
          {subtitulo ? <p className="truncate text-[13px] text-suave">{subtitulo}</p> : null}
        </div>
      </header>

      <div className="flex-1 overflow-y-auto overscroll-contain px-4 py-5">{children}</div>

      {pie ? (
        <div
          className="border-t border-linea bg-white px-4 py-3"
          style={{ paddingBottom: 'calc(0.75rem + env(safe-area-inset-bottom))' }}
        >
          {pie}
        </div>
      ) : null}
    </div>
  );
}
