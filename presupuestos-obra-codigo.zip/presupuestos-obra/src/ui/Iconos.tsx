type Props = { className?: string };

const base = 'h-6 w-6';

export function IconoDocumento({ className = base }: Props) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden className={className}>
      <path d="M6 3.5h7.5L18 8v12.5H6z" strokeLinejoin="round" />
      <path d="M13.5 3.5V8H18M9 12h6M9 15.5h6" strokeLinecap="round" />
    </svg>
  );
}

export function IconoEtiqueta({ className = base }: Props) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden className={className}>
      <path d="M4 10.5V5h5.5l9 9-5.5 5.5z" strokeLinejoin="round" />
      <circle cx="8" cy="8" r="1.4" />
    </svg>
  );
}

export function IconoAjustes({ className = base }: Props) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden className={className}>
      <circle cx="12" cy="12" r="3" />
      <path d="M4.5 12h2M17.5 12h2M12 4.5v2M12 17.5v2M7 7l1.4 1.4M15.6 15.6 17 17M17 7l-1.4 1.4M8.4 15.6 7 17" strokeLinecap="round" />
    </svg>
  );
}

export function IconoBasura({ className = 'h-5 w-5' }: Props) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden className={className}>
      <path d="M5 7h14M10 4.5h4M7 7l.8 12h8.4L17 7" strokeLinejoin="round" strokeLinecap="round" />
    </svg>
  );
}

export function IconoMas({ className = 'h-5 w-5' }: Props) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden className={className}>
      <path d="M12 5v14M5 12h14" strokeLinecap="round" />
    </svg>
  );
}

export function IconoMenos({ className = 'h-5 w-5' }: Props) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden className={className}>
      <path d="M5 12h14" strokeLinecap="round" />
    </svg>
  );
}

export function IconoLupa({ className = 'h-5 w-5' }: Props) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden className={className}>
      <circle cx="10.8" cy="10.8" r="6.3" />
      <path d="M15.4 15.4 19.8 19.8" strokeLinecap="round" />
    </svg>
  );
}

export function IconoFlecha({ className = 'h-5 w-5' }: Props) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden className={className}>
      <path d="M19 12H5.5M11 5.5 4.5 12l6.5 6.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
