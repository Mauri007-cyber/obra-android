import type { InputHTMLAttributes, TextareaHTMLAttributes } from 'react';

const caja =
  'flex items-center gap-2 rounded-2xl border border-linea bg-white px-4 focus-within:border-acento focus-within:ring-2 focus-within:ring-acento/15';

function identificadorDe(etiqueta: string): string {
  return `campo-${etiqueta.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`;
}

export function Campo({
  etiqueta,
  ayuda,
  sufijo,
  className = '',
  id,
  ...props
}: InputHTMLAttributes<HTMLInputElement> & { etiqueta: string; ayuda?: string; sufijo?: string }) {
  const identificador = id ?? identificadorDe(etiqueta);
  return (
    <div className={className}>
      <label
        htmlFor={identificador}
        className="mb-1.5 block text-[14px] font-semibold tracking-wide text-suave"
      >
        {etiqueta}
      </label>
      <div className={caja}>
        <input
          id={identificador}
          className="h-14 w-full bg-transparent text-[18px] outline-none placeholder:text-suave/45"
          {...props}
        />
        {sufijo ? <span className="shrink-0 text-[15px] text-suave">{sufijo}</span> : null}
      </div>
      {ayuda ? <p className="mt-1.5 text-[13px] leading-snug text-suave">{ayuda}</p> : null}
    </div>
  );
}

export function CampoArea({
  etiqueta,
  ayuda,
  className = '',
  id,
  ...props
}: TextareaHTMLAttributes<HTMLTextAreaElement> & { etiqueta: string; ayuda?: string }) {
  const identificador = id ?? identificadorDe(etiqueta);
  return (
    <div className={className}>
      <label
        htmlFor={identificador}
        className="mb-1.5 block text-[14px] font-semibold tracking-wide text-suave"
      >
        {etiqueta}
      </label>
      <textarea
        id={identificador}
        rows={4}
        className="w-full rounded-2xl border border-linea bg-white px-4 py-3 text-[17px] leading-snug outline-none placeholder:text-suave/45 focus:border-acento focus:ring-2 focus:ring-acento/15"
        {...props}
      />
      {ayuda ? <p className="mt-1.5 text-[13px] leading-snug text-suave">{ayuda}</p> : null}
    </div>
  );
}
