import type { ButtonHTMLAttributes } from 'react';

type Variante = 'primario' | 'secundario' | 'fantasma' | 'peligro';

const variantes: Record<Variante, string> = {
  primario: 'bg-acento text-white shadow-sm active:bg-acento-fuerte',
  secundario: 'bg-white text-tinta border border-linea active:bg-papel',
  fantasma: 'bg-transparent text-tinta active:bg-black/5',
  peligro: 'bg-white text-mal border border-mal/30 active:bg-mal/5'
};

export function Boton({
  variante = 'primario',
  grande = false,
  className = '',
  children,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variante?: Variante; grande?: boolean }) {
  return (
    <button
      className={`inline-flex items-center justify-center gap-2 rounded-2xl px-5 font-semibold transition-colors disabled:opacity-50 ${
        grande ? 'h-16 text-[18px]' : 'h-14 text-[17px]'
      } ${variantes[variante]} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
}
