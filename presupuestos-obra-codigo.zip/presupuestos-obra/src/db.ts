import Dexie, { type Table } from 'dexie';

export type Unidad = 'm2' | 'ml' | 'ud' | 'h' | 'global' | 'kg';
export type Estado = 'borrador' | 'enviado' | 'aceptado' | 'rechazado' | 'terminado';
export type TipoPartida = 'material' | 'mano_obra' | 'mixto';

export interface Linea {
  id: string;
  concepto: string;
  cantidad: number;
  unidad: Unidad;
  precioUnitario: number;
  tipo: TipoPartida;
  precioId?: string;
}

export interface Presupuesto {
  id: string;
  numero: string;
  clienteNombre: string;
  obraTitulo: string;
  obraDireccion?: string;
  fecha: string;
  validezDias: number;
  estado: Estado;
  lineas: Linea[];
  notas?: string;
  creadoEn: string;
  actualizadoEn: string;
  enviadoEn?: string;
}

export interface Precio {
  id: string;
  concepto: string;
  unidad: Unidad;
  precioUnitario: number;
  tipo: TipoPartida;
  vecesUsado: number;
  ultimaVez: string;
}

export interface Cliente {
  id: string;
  nombre: string;
  telefono?: string;
}

export interface Ajustes {
  id: 'unico';
  nombre: string;
  oficio: string;
  telefono: string;
  nif?: string;
  direccion?: string;
  validezDias: number;
  serie: string;
  siguienteNumero: number;
  ultimaCopia?: string;
}

class BaseDatos extends Dexie {
  presupuestos!: Table<Presupuesto, string>;
  precios!: Table<Precio, string>;
  clientes!: Table<Cliente, string>;
  ajustes!: Table<Ajustes, string>;

  constructor() {
    super('presupuestos-obra');
    this.version(1).stores({
      presupuestos: 'id, fecha, estado, clienteNombre, actualizadoEn',
      precios: 'id, concepto, vecesUsado, ultimaVez',
      clientes: 'id, nombre',
      ajustes: 'id'
    });
  }
}

export const db = new BaseDatos();
