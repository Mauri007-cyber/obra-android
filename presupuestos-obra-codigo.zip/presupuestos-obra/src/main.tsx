import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import { vigilarActualizaciones } from './lib/actualizar';
import './index.css';

vigilarActualizaciones();

ReactDOM.createRoot(document.getElementById('root') as HTMLElement).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
