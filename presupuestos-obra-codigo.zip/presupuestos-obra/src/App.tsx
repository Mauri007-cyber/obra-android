import { useEffect, useState } from 'react';
import { asegurarAjustes } from './lib/repo';
import { ProveedorAviso } from './ui/aviso';
import { Lista } from './features/presupuestos/Lista';
import { Editor } from './features/presupuestos/Editor';
import { Precios } from './features/precios/Precios';
import { Ajustes } from './features/ajustes/Ajustes';
import { IconoAjustes, IconoDocumento, IconoEtiqueta } from './ui/Iconos';

type Vista =
  | { tipo: 'lista' }
  | { tipo: 'editor'; id: string }
  | { tipo: 'precios' }
  | { tipo: 'ajustes' };

export default function App() {
  const [vista, setVista] = useState<Vista>({ tipo: 'lista' });

  useEffect(() => {
    void asegurarAjustes();
  }, []);

  const pestanas = [
    { tipo: 'lista', etiqueta: 'Presupuestos', Icono: IconoDocumento },
    { tipo: 'precios', etiqueta: 'Mis precios', Icono: IconoEtiqueta },
    { tipo: 'ajustes', etiqueta: 'Ajustes', Icono: IconoAjustes }
  ] as const;

  return (
    <ProveedorAviso>
      <div className="mx-auto min-h-dvh w-full max-w-md bg-papel">
        {vista.tipo === 'lista' ? (
          <Lista
            onAbrir={(id) => setVista({ tipo: 'editor', id })}
            onAjustes={() => setVista({ tipo: 'ajustes' })}
          />
        ) : null}

        {vista.tipo === 'editor' ? (
          <Editor id={vista.id} onVolver={() => setVista({ tipo: 'lista' })} />
        ) : null}

        {vista.tipo === 'precios' ? <Precios /> : null}
        {vista.tipo === 'ajustes' ? <Ajustes /> : null}
      </div>

      {vista.tipo !== 'editor' ? (
        <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-linea bg-white/95 backdrop-blur">
          <div
            className="mx-auto flex max-w-md"
            style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
          >
            {pestanas.map(({ tipo, etiqueta, Icono }) => {
              const activo = vista.tipo === tipo;
              return (
                <button
                  key={tipo}
                  type="button"
                  onClick={() => setVista({ tipo })}
                  aria-current={activo ? 'page' : undefined}
                  className={`flex flex-1 flex-col items-center gap-1 pb-2 pt-2.5 text-[11.5px] font-semibold transition-colors ${
                    activo ? 'text-acento' : 'text-suave'
                  }`}
                >
                  <Icono className="h-6 w-6" />
                  {etiqueta}
                </button>
              );
            })}
          </div>
        </nav>
      ) : null}
    </ProveedorAviso>
  );
}
