import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { VitePWA } from 'vite-plugin-pwa';

const host = process.env.PREVIEW_HOST;

export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      // La activación la controla `src/lib/actualizar.ts`, que espera a que no
      // haya nada a medio escribir antes de recargar.
      registerType: 'prompt',
      injectRegister: false,
      includeAssets: ['icono-192.png', 'icono-512.png', 'icono-maskable.png'],
      manifest: {
        name: 'Presupuestos de obra',
        short_name: 'Presupuestos',
        description: 'Presupuestos de obra en el móvil, sin conexión.',
        lang: 'es',
        start_url: '/',
        scope: '/',
        display: 'standalone',
        orientation: 'portrait',
        background_color: '#f6f4f0',
        theme_color: '#1c1917',
        icons: [
          { src: 'icono-192.png', sizes: '192x192', type: 'image/png' },
          { src: 'icono-512.png', sizes: '512x512', type: 'image/png' },
          { src: 'icono-maskable.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' }
        ]
      },
      workbox: {
        globPatterns: ['**/*.{js,css,html,png,svg,woff2}'],
        navigateFallback: 'index.html',
        cleanupOutdatedCaches: true,
        // La versión nueva espera a que `actualizar.ts` le diga cuándo entrar;
        // al activarse toma el control de la pestaña abierta y esta se recarga.
        skipWaiting: false,
        clientsClaim: true
      }
    })
  ],
  server: {
    host: '0.0.0.0',
    port: 3000,
    strictPort: true,
    allowedHosts: host ? [host, 'localhost', '127.0.0.1'] : undefined
  }
});
