# Estrategia de producto y diseño

## 1. La idea en una frase

Un cuaderno de presupuestos que cabe en el bolsillo, que no se pierde, que calcula solo y
que manda el presupuesto al cliente por WhatsApp en un toque.

## 2. Objetivos

| Objetivo | Cómo se mide |
|---|---|
| Hacer un presupuesto en menos de 5 minutos | Cronometrado con él, en su móvil, con un trabajo real |
| No perder nunca un presupuesto | Lista con todos, buscables, con estado |
| Reutilizar precios propios | Catálogo de precios usados, con "los más usados" arriba |
| Parecer profesional ante el cliente | PDF limpio, con su nombre, teléfono y condiciones |
| Cero aprendizaje | Lo usa sin manual, tras una demostración de 2 minutos |

## 3. Anti-objetivos (lo que NO es, y por qué)

- **No es un programa de facturación.** Un presupuesto no es una factura. Facturar obliga a
  requisitos fiscales (en España, Verifactu) que añaden complejidad legal y miedo. Fuera.
- **No es contabilidad ni control de gastos.** Fase 4 como mucho, y solo si lo pide.
- **No es un CRM.** Sin embudos, sin seguimiento automático, sin emails.
- **No tiene cuentas de usuario.** Sin registro, sin "he olvidado mi contraseña".
- **No tiene panel de administración ni ajustes avanzados.** Los ajustes caben en una pantalla.
- **No es multiusuario.** Un móvil, una persona.
- **No es una app de tienda de aplicaciones.** PWA instalable.

## 4. Principios de diseño (los que mandan sobre cualquier ocurrencia)

1. **Una cosa por pantalla.** Si hay que decidir entre dos cosas, van en dos pantallas.
2. **Grande de verdad.** Texto base 18–20 px, botones de 56 px de alto mínimo, totales a 32–40 px.
   Se usa a pleno sol, de pie, con las manos sucias.
3. **Nada se pierde.** Autoguardado en cada cambio. Nunca hay botón "Guardar" que se pueda olvidar.
4. **Deshacer en vez de preguntar.** "¿Seguro que quieres borrar?" se sustituye por "Borrado. Deshacer".
5. **Texto, no iconos.** Icono siempre acompañado de palabra. Ningún icono mudo.
6. **Nunca bloquear.** Si falta el teléfono del cliente, se puede seguir y se avisa al final.
7. **Lenguaje de obra.** "Partida", "m²", "mano de obra", "IVA". Nada de "ítem", "recurso", "entidad".
8. **Errores en positivo y en su idioma.** "Falta el nombre del cliente" en vez de un código.
9. **Offline por defecto.** La app no dice "sin conexión": simplemente funciona.
10. **Un solo camino principal.** Botón grande "Nuevo presupuesto" siempre visible en la lista.

## 5. Flujo principal (el camino que hay que clavar)

```
Móvil → icono "Presupuestos"
   │
   ├─ Lista: presupuestos ordenados por fecha, buscador arriba,
   │         botón enorme "+ Nuevo presupuesto"
   │
   ├─ Nuevo → ¿Para quién? (nombre del cliente, se puede dictar)
   │           ¿Qué obra? (opcional: "Reforma baño Calle Mayor")
   │
   ├─ Partidas → "+ Añadir partida"
   │        ├─ Escribir o dictar: "Alicatado de baño"
   │        ├─ Cantidad: 25        Unidad: m²
   │        ├─ Precio: 18 €
   │        └─ o elegir de "Mis precios" (los 6 más usados, botones grandes)
   │
   ├─ Total siempre visible abajo: "TOTAL 1.245,00 €" (con IVA)
   │
   └─ "Enviar al cliente"
            → genera PDF → menú del móvil → WhatsApp
            → queda marcado como "Enviado" con fecha
            → después: "Aceptado" / "Rechazado" / "Terminado"
```

## 6. Pantallas (bocetos en texto)

### 6.1 Inicio — la lista

```
┌────────────────────────────────┐
│  Presupuestos          ⚙︎       │
│  ┌──────────────────────────┐  │
│  │ 🔍 Buscar cliente u obra │  │
│  └──────────────────────────┘  │
│                                │
│  ENVIADO · 12 nov              │
│  Juan Pérez — Reforma baño     │
│  1.245,00 €                    │
│  ────────────────────────────  │
│  ACEPTADO · 8 nov              │
│  Comunidad Los Olmos — Tabique │
│  640,00 €                      │
│                                │
│ ┌────────────────────────────┐ │
│ │      + NUEVO PRESUPUESTO   │ │
│ └────────────────────────────┘ │
└────────────────────────────────┘
```

- Estado en mayúsculas y color: gris (borrador), azul (enviado), verde (aceptado),
  rojo suave (rechazado), negro (terminado).
- Vacío: "Todavía no hay presupuestos. Pulsa el botón verde para hacer el primero."

### 6.2 Editor de presupuesto

```
┌────────────────────────────────┐
│ ←  Presupuesto 2026-014        │
│                                │
│ Cliente   [ Juan Pérez      ]  │
│ Obra      [ Reforma baño    ]  │
│                                │
│ PARTIDAS                       │
│ ┌────────────────────────────┐ │
│ │ Alicatado baño             │ │
│ │ 25 m² × 18,00 €   450,00 € │ │
│ └────────────────────────────┘ │
│ ┌────────────────────────────┐ │
│ │ Retirada escombro          │ │
│ │ 1 ud × 180,00 €   180,00 € │ │
│ └────────────────────────────┘ │
│                                │
│ ┌────────────────────────────┐ │
│ │      + AÑADIR PARTIDA      │ │
│ └────────────────────────────┘ │
│                                │
│ Base imponible        1.029,00 │
│ IVA 21%                 216,09 │
│ ══════════════════════════════ │
│ TOTAL                 1.245,09 │
│                                │
│ ┌────────────────────────────┐ │
│ │   ENVIAR AL CLIENTE (PDF)  │ │
│ └────────────────────────────┘ │
└────────────────────────────────┘
```

### 6.3 Añadir partida (pantalla completa, no modal pequeño)

```
┌────────────────────────────────┐
│ ←  Nueva partida               │
│                                │
│ ¿Qué es?  [ Alicatado baño  🎤]│
│                                │
│ Cantidad  [ 25        ]        │
│ Unidad    [m²][ml][ud][h][global]│
│ Precio    [ 18,00 ] € / m²     │
│                                │
│ Va a salir:      450,00 €      │
│                                │
│ ┌────────────────────────────┐ │
│ │          AÑADIR            │ │
│ └────────────────────────────┘ │
│                                │
│ MIS PRECIOS                     │
│ [Alicatado 18 €] [Enfoscado 12 €]│
│ [Solado 22 €]   [Pintura 6 €]  │
└────────────────────────────────┘
```

### 6.4 Mis precios

Lista de partidas guardadas con su precio, ordenadas por uso. Un toque añade la partida al
presupuesto. Botón "Guardar esta partida en mis precios" al terminar una partida nueva,
nunca antes (nadie rellena un catálogo por gusto).

### 6.5 Ajustes (una sola pantalla)

Sus datos (nombre, teléfono, NIF opcional, dirección), logo (opcional, una foto),
IVA por defecto (21% / 10%), validez del presupuesto (30 días), y **Copia de seguridad**.

## 7. Tono y textos

- Frases cortas, en segunda persona, sin tecnicismos: "¿Para quién es el presupuesto?"
- Nunca "Error", "inválido", "no permitido". Sí: "Pon un precio para poder calcular".
- Números con formato español: `1.245,09 €`, coma decimal en los campos.
- Nada de signos de exclamación, nada de emojis en la interfaz.

## 8. Accesibilidad y uso real

- Contraste mínimo AA, y probado a la luz del día (fondo blanco, texto casi negro, acento oscuro).
- Zonas táctiles de 56 px, separadas 8 px como mínimo, para dedos con guantes.
- Sin gestos ocultos ni menús deslizables: todo lo importante es un botón visible.
- Sin animaciones que retrasen: transiciones de 150 ms como máximo.
- Funciona con el móvil en horizontal y en vertical.
- El teclado numérico aparece solo cuando toca un número; el dictado usa el micrófono del teclado.

## 9. Cómo se prueba con él (no con nosotros)

1. **Fase 0 — mirar, no preguntar.** Que haga un presupuesto como lo hace hoy, delante de
   nosotros. Anotar palabras que usa, orden de las partidas, qué calcula de cabeza.
2. **Prototipo de papel o clicable** con 5 partidas y su nombre real. Que lo toque.
3. **Prueba de fuego:** tres presupuestos reales en la Fase 1, sin ayuda, con nosotros solo mirando.
   Cada vez que pida ayuda, eso es un fallo de diseño, no del usuario.
4. Al final de cada presupuesto: una sola pregunta — "¿qué ha sido lo más incómodo?".
