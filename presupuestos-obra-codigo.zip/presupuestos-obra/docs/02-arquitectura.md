# Arquitectura

## 1. Las tres opciones que había

### Opción A — PWA 100% local (sin servidor)

React + Vite empaquetado como PWA. Los datos en el propio móvil (IndexedDB). El PDF se
genera en el dispositivo. Copia de seguridad = un archivo que se puede mandar por WhatsApp
o guardar en Drive.

- **A favor:** funciona siempre, sin cobertura; cero login; cero coste de servidor; cero
  problemas de privacidad; es la opción más rápida de construir y la más difícil de romper.
- **En contra:** si pierde o rompe el móvil, los datos se van con él. Hay que resolver la
  copia de seguridad con mucho cuidado (botón visible + recordatorio + exportación automática
  al compartir).

### Opción B — PWA + Supabase (nube desde el día uno)

Postgres para presupuestos, Storage para fotos y PDFs, login por enlace mágico o PIN.

- **A favor:** copia en la nube automática, varios dispositivos, nunca se pierde nada.
- **En contra:** introduce un login (punto de abandono real para este usuario), dependencia
  de la red en obra, sincronización offline con conflictos, y más superficie donde fallar.
  Para una persona que no maneja tecnología, "revisa tu correo para entrar" es un muro.

### Opción C — Local-first, con nube opcional después (recomendada)

Se construye A, pero con la puerta de datos aislada (un repositorio con la misma interfaz).
En la Fase 3 se puede activar "guardar copia en la nube" sin tocar las pantallas.

- **A favor:** el MVP es simple y sólido; la copia en la nube llega cuando ya la usa, no
  antes; si la nube falla, la app sigue funcionando.
- **En contra:** hay que escribir la capa de datos con disciplina desde el principio (no
  llamar a IndexedDB desde los componentes).

**Decisión propuesta: C**, ejecutando A en la Fase 1. Motivo: el riesgo número uno de este
proyecto es el abandono por fricción, no la falta de sincronización.

## 2. Stack

| Pieza | Elección | Por qué |
|---|---|---|
| Framework | **React + TypeScript + Vite** | Rápido, sin servidor, PWA sencilla, ecosistema maduro |
| Estilos | **Tailwind CSS** con tokens propios | Escala tipográfica y de espaciado consistente, sin CSS suelto |
| Estado | Hooks + repositorio propio (nada de Redux) | La app es pequeña; menos capas, menos fallos |
| Persistencia | **IndexedDB con Dexie** | Datos estructurados, consultas, transacciones, funciona offline |
| PWA | **vite-plugin-pwa** (Workbox) | Precache del shell, actualización automática, manifest |
| PDF | **pdf-lib** | Generación determinista en el dispositivo, sin servidor, control total del diseño |
| Compartir | **Web Share API (nivel 2, con archivos)** | Abre WhatsApp directamente con el PDF adjunto |
| Fechas / números | `Intl` nativo | Formato español sin dependencias |
| Tests | **Vitest** + Testing Library (solo cálculos y flujos críticos) | Verificación barata de totales y guardado |
| Despliegue | Estático (Sites / cualquier hosting de ficheros) | No necesita backend |

**Descartado:** Next.js para la Fase 1 (no hay SSR ni SEO que aprovechar, pesa más y el
offline es más frágil); Flutter/React Native (obliga a tiendas de apps y a un proceso de
publicación que no aporta nada aquí).

## 3. Estructura de carpetas

```
src/
  app/            App.tsx, router, layout, pantalla de actualización
  features/
    presupuestos/ lista, editor, detalle, estados
    partidas/     formulario de partida, unidades, cálculo en vivo
    precios/      catálogo "Mis precios"
    ajustes/      datos del albañil, IVA, copia de seguridad
  lib/
    db.ts         esquema Dexie y migraciones
    repo/         presupuestos.repo.ts, precios.repo.ts, ajustes.repo.ts  ← única puerta a los datos
    calculos.ts   base imponible, descuento, IVA, totales
    pdf.ts        plantilla A4 y generación del PDF
    compartir.ts  Web Share API + fallback de descarga
    copia.ts      exportar / importar JSON
    formato.ts    euros, fechas, números es-ES
  ui/             Boton, Campo, Numero, Hoja, Tarjeta, Aviso, Deshacer
  styles/
```

Regla: **ningún componente toca Dexie directamente**. Todo pasa por `lib/repo`, para poder
cambiar el almacenamiento (nube) en la Fase 3 sin reescribir pantallas.

## 4. Modelo de datos

```ts
type ID = string;
type Unidad = 'm2' | 'ml' | 'ud' | 'h' | 'global' | 'kg';
type Estado = 'borrador' | 'enviado' | 'aceptado' | 'rechazado' | 'terminado';

interface Ajustes {
  id: 'unico';
  nombre: string;          // "Antonio García"
  oficio: string;          // "Albañilería"
  telefono: string;
  nif?: string;
  direccion?: string;
  logo?: string;           // dataURL, opcional
  validezDias: number;     // 30
  serie: string;           // "2026"
  siguienteNumero: number;
  ultimaCopia?: string;    // ISO, para el recordatorio
}

interface Cliente {
  id: ID;
  nombre: string;
  telefono?: string;
  direccion?: string;
}

interface Linea {
  id: ID;
  concepto: string;
  cantidad: number;
  unidad: Unidad;
  precioUnitario: number;  // sin IVA
  tipo: 'material' | 'mano_obra' | 'mixto';
  precioId?: ID;           // si vino del catálogo
}

interface Presupuesto {
  id: ID;
  numero: string;          // "2026-014"
  clienteNombre: string;
  clienteId?: ID;
  obra: { titulo: string; direccion?: string; descripcion?: string };
  fecha: string;           // ISO
  validezDias: number;
  estado: Estado;
  lineas: Linea[];
  notas?: string;
  condiciones?: string;
  fotos?: string[];        // dataURL comprimido (Fase 2)
  creadoEn: string;
  actualizadoEn: string;
  enviadoEn?: string;
}

interface Precio {
  id: ID;
  concepto: string;
  unidad: Unidad;
  precioUnitario: number;
  tipo: Linea['tipo'];
  vecesUsado: number;
  ultimaVez: string;
}
```

Índices Dexie: `presupuestos: id, fecha, estado, clienteNombre`, `precios: id, vecesUsado`,
`clientes: id, nombre`.

## 5. Cálculos (la única lógica que no puede fallar)

**Sin IVA por decisión de producto**: el importe es el que se le dice al cliente.

```
importeLínea = cantidad × precioUnitario        // redondeado a céntimos
TOTAL        = Σ importeLínea                    // sumado en céntimos enteros
```

- Cada línea se redondea a céntimos y el total se suma **en céntimos enteros**: el total
  coincide exactamente con la suma de los importes que el cliente ve en el PDF.
- Funciones puras en `lib/calculos.ts`, con tests: 0 líneas, 1 línea, cantidades decimales
  (2,5 m²), precios con céntimos, tolerancia a valores no numéricos.
- Test de invariante: `total === Σ subtotalLinea`, sin desviación de un céntimo.

## 6. PWA: lo que hay que acertar

```jsonc
// manifest.webmanifest
{
  "name": "Presupuestos de Antonio",
  "short_name": "Presupuestos",
  "start_url": "/",
  "display": "standalone",
  "orientation": "portrait",
  "lang": "es",
  "background_color": "#ffffff",
  "theme_color": "#1f2937",
  "icons": [
    { "src": "/icono-192.png", "sizes": "192x192", "type": "image/png" },
    { "src": "/icono-512.png", "sizes": "512x512", "type": "image/png" },
    { "src": "/icono-maskable.png", "sizes": "512x512", "type": "image/png", "purpose": "maskable" }
  ]
}
```

- `registerType: 'autoUpdate'` y `skipWaiting`: se actualiza sola al abrir. Un aviso de
  "hay una versión nueva" es una decisión técnica que este usuario no debe tomar.
- Precache del shell (HTML, JS, CSS, fuentes, iconos). Sin CDNs externos: todo servido
  desde el propio origen, o el offline se rompe.
- Instalación: capturar `beforeinstallprompt` y mostrar **una vez**, tras el primer
  presupuesto guardado, un aviso claro: "Añádelo a la pantalla de inicio y ábrelo como una app".
- Sin `localStorage` para datos de negocio (se borra con facilidad y no es transaccional).
- Aviso persistente y honesto en Ajustes: "Tus presupuestos están en este móvil. Última
  copia: 12/11/2026".

## 7. PDF: la carta de presentación

Plantilla única A4, generada con pdf-lib:

```
┌───────────────────────────────────────────────┐
│  ANTONIO GARCÍA — Albañilería                 │
│  600 000 000 · NIF 00000000X                  │
│                                               │
│  PRESUPUESTO 2026-014         Fecha: 19/11/26 │
│  Cliente: Juan Pérez                          │
│  Obra: Reforma baño C/ Mayor 12               │
│  ───────────────────────────────────────────  │
│  CONCEPTO            CANT.  PRECIO    TOTAL   │
│  Alicatado baño      25 m²  18,00 €  450,00 € │
│  Retirada escombro    1 ud 180,00 €  180,00 € │
│  ───────────────────────────────────────────  │
│                             TOTAL:   630,00 € │
│                                               │
│  Validez: 30 días. Presupuesto no contractual │
│  hasta su aceptación por escrito.             │
│  Firma y fecha del cliente: ______________    │
└───────────────────────────────────────────────┘
```

- Fuente estándar (Helvetica) para no meter binarios; si se quiere una fuente propia, se
  incrusta subseteada (una sola, regular + negrita).
- Nombre de archivo: `Presupuesto 2026-014 - Juan Pérez.pdf`.
- Compartir: `navigator.share({ files: [pdf] })`; si no está disponible, descarga directa.
- Casos límite: muchas líneas (salto de página con cabecera repetida), conceptos largos
  (recorte con elipsis, nunca solapamiento), importes de 6 cifras, tildes y ñ.

## 8. Copias de seguridad (el punto débil de la opción local)

1. **Exportar** un único archivo `presupuestos-2026-11-19.json` con todo (presupuestos,
   precios, ajustes) → compartir por WhatsApp/Drive o guardar en el móvil.
2. **Importar** el mismo archivo (fusiona por `id`, nunca duplica).
3. **Recordatorio**: si `ultimaCopia` tiene más de 15 días y hay más de 3 presupuestos,
   una tarjeta discreta en la lista: "Hace tiempo que no guardas una copia. Guardar ahora".
4. En la Fase 3, lo mismo pero automático contra la nube.

## 9. Rendimiento y límites

- Objetivo: abrir en menos de 1,5 s en un Android modesto, con la app ya instalada.
- Presupuesto con 60 partidas: la lista debe seguir fluida (virtualización solo si hace falta).
- Fotos (Fase 2): comprimir a 1600 px de lado y ~300 KB antes de guardar; IndexedDB no es
  un carrete de fotos.
- Sin dependencias grandes que no se usen. Presupuesto de arranque: < 200 KB gzip de JS.

## 10. Riesgos técnicos

| Riesgo | Mitigación |
|---|---|
| IndexedDB borrado por el sistema con poco espacio | Exportación visible + recordatorio + (Fase 3) nube |
| `navigator.share` con archivos no soportado en algún navegador | Fallback a descarga y luego compartir desde el gestor de archivos |
| PDF mal maquetado con muchos conceptos | Pruebas con 30, 60 y 100 líneas desde el primer día |
| Descuadres de céntimos | Cálculo centralizado, redondeo al final, tests |
| Actualización que rompe datos guardados | Versionado de esquema Dexie con migraciones y prueba de actualización |
| Dictado inexistente o mal | El dictado es del teclado del móvil: no se implementa nada, se documenta |
