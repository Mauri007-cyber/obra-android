# Fase 1 — MVP usable

**Definición de terminado de la fase:** su padre hace tres presupuestos reales seguidos,
solo, en su móvil, los envía por WhatsApp y los encuentra después. Sin llamar a nadie.

> Estado: **implementado y compilando**. Falta la prueba real con él (ver punto 6).

## 1. Dentro del alcance

1. Instalar la app en el móvil (PWA) y abrirla como una app.
2. Crear un presupuesto: cliente, obra y partidas (concepto, cantidad, unidad, precio).
3. Ver el total en todo momento, con cálculo correcto y formato español.
4. Guardar automáticamente, sin botón de guardar.
5. Lista de presupuestos con buscador por cliente u obra, y estados.
6. Catálogo "Mis precios" que se llena solo al usar partidas.
7. Generar el PDF y compartirlo por WhatsApp.
8. Ajustes mínimos: sus datos, numeración, validez.
9. Copia de seguridad manual (exportar / importar).
10. Funcionar sin conexión, también recién instalada.

## 2. Fuera del alcance (Fase 1)

- IVA, base imponible y facturación: el importe es el que se le dice al cliente.
- Fotos de la obra, firma del cliente, plantillas de presupuesto, duplicar presupuesto.
- Logo propio en el PDF.
- Sincronización, cuentas, nube, multiusuario.
- Varios idiomas, modo oscuro, notificaciones, informes y gráficos.
- Tests end-to-end y auditorías: se prueban los cálculos, nada más.

## 3. Backlog con criterios de aceptación

### B1. Base del proyecto — hecho
- [x] Vite + React + TypeScript + Tailwind, con tokens de tipografía, color y espaciado.
- [x] PWA configurada (manifest, iconos 192/512/maskable, service worker).
- [x] **Se actualiza sola sin perder nada**: busca versión nueva al abrir, al recuperar
      conexión, al volver a primer plano y cada 30 minutos. La versión nueva espera
      (no entra en caliente) y solo se aplica cuando no hay ninguna ventana abierta ni
      el cursor en un campo; antes de recargar, el editor guarda lo pendiente.
- [x] Desplegable como sitio estático (`npm run build` → `dist/`).
- **Acepta:** se instala desde el navegador, aparece el icono y abre sin conexión.

### B2. Modelo de datos y repositorio — hecho
- [x] Esquema Dexie con `presupuestos`, `precios`, `clientes`, `ajustes` e índices.
- [x] `lib/repo` con todas las operaciones y consultas reactivas.
- [x] `lib/calculos.ts` con tests (0 líneas, decimales, céntimos, redondeo por línea).
- **Acepta:** los tests pasan; un presupuesto persiste tras cerrar y reabrir la app.

### B3. Pantalla de lista — hecho
- [x] Orden por fecha descendente, tarjeta con estado, cliente, obra e importe total.
- [x] Buscador por cliente, obra y número (sin tildes, insensible a mayúsculas).
- [x] Estado vacío con instrucción clara.
- [x] Botón fijo "+ Nuevo presupuesto" de 56 px mínimo.
- **Acepta:** con 20 presupuestos, encontrar uno concreto en menos de 5 segundos.

### B4. Editor de presupuesto — hecho
- [x] Cabecera editable: cliente, obra y dirección.
- [x] Lista de partidas con subtotal por línea; tocar una línea la edita; borrar con "Deshacer".
- [x] Total fijo abajo, en 24 px o más.
- [x] Autoguardado a los 350 ms de cada cambio, con indicador "Guardado".
- [x] Numeración automática `año-NNN` al crear, ajustable en Ajustes.
- **Acepta:** cerrar la app a mitad de edición y al volver está todo.

### B5. Añadir / editar partida — hecho
- [x] **Dos formas de cobrar**, a un toque: **partida entera** (precio cerrado, sin
      cantidades: «Alicatar el baño, 1.000 € material incluido») y **por medida**
      (cantidad × precio: m², ml, ud, h, kg). La partida entera es la opción por defecto.
- [x] Concepto (con dictado del teclado), precio con coma decimal, unidad,
      tipo (material / mano de obra / todo incluido).
- [x] Subtotal en vivo ("Va a salir: 450,00 €").
- [x] "Mis precios" debajo: los 6 más usados, un toque para rellenar la partida.
- [x] Casilla "Guardar en Mis precios" al crear una partida nueva.
- **Acepta:** crear una partida con coma decimal, sin errores de redondeo, en menos de 20 segundos.

### B6. "Mis precios" — hecho
- [x] Lista ordenada por uso, con buscador y precio visible.
- [x] Editar precio sin afectar a presupuestos antiguos (los importes ya guardados no cambian).
- [x] Borrar con "Deshacer"; alta manual de precios.
- **Acepta:** un precio editado hoy no cambia el importe de un presupuesto de la semana pasada.

### B7. PDF y compartir — hecho
- [x] Plantilla A4 con sus datos, número, fecha, cliente, obra, tabla, total, validez y firma.
- [x] Saltos de página con cabecera repetida; conceptos largos con salto de línea.
- [x] **Vista previa antes de enviar**: el botón «Ver y enviar» enseña las páginas del PDF
      tal cual van a salir; desde ahí se envía o se vuelve a corregir (pdf.js, cargado solo al abrirla).
- [x] Nombre de archivo legible y compartir con el menú del sistema (WhatsApp).
- [x] Al compartir, el presupuesto pasa a "Enviado" con fecha.
- **Acepta:** el PDF se abre bien en el móvil y un tercero entiende el presupuesto sin explicación.

### B8. Ajustes — hecho
- [x] Nombre, oficio, teléfono, NIF y dirección.
- [x] Serie, siguiente número y validez por defecto.
- [x] Copia de seguridad: exportar JSON, importar JSON (fusiona sin duplicar), fecha de la última.
- **Acepta:** exportar, borrar la app, reinstalar, importar y recuperar todo.

### B9. Robustez de uso real — hecho, pendiente de verlo en su móvil
- [x] Funciona en vertical y horizontal, con una mano.
- [x] Nada bloquea: se puede guardar sin teléfono ni dirección del cliente.
- [x] Textos sin jerga, revisados uno a uno.
- [x] Ninguna acción habitual exige más de 3 toques desde la lista.
- **Acepta:** contraste y tamaño comprobados a plena luz, en su móvil.

## 4. Orden de trabajo seguido

| Sesión | Trabajo | Resultado |
|---|---|---|
| 1 | Diseño, decisiones y documentación | Enfoque aprobado |
| 2 | B1 + B2 (base, datos, cálculos) | App vacía instalable, tests de cálculo en verde |
| 3 | B3 + B4 (lista y editor) | Se crean y guardan presupuestos |
| 4 | B5 + B6 (partidas y catálogo) | Presupuesto completo con totales correctos |
| 5 | B7 (PDF y compartir) | Presupuesto enviado por WhatsApp |
| 6 | B8 + B9 (ajustes, copias, repaso) | Producto terminado |
| 7 | **Prueba real con él** | Lista de fricciones para la Fase 2 |

## 5. Cómo se valida (y qué no se hace)

- `npm test`: tests de `calculos.ts` (totales, decimales, céntimos) y lectura de números.
- `npm run build`: comprobación de tipos y build de producción con service worker.
- Prueba manual en el móvil real: crear, editar, enviar, cerrar, reabrir, importar copia.
- Prueba con 60 partidas para ver el PDF y la fluidez de la lista.
- No se escriben tests end-to-end, ni auditorías de accesibilidad o rendimiento en esta fase.

## 6. Señales de que la Fase 1 ha fallado

- Pide ayuda más de una vez por presupuesto.
- Vuelve al papel o a Word en la segunda prueba.
- Tarda más de 10 minutos en un presupuesto que antes hacía en 5.
- No encuentra un presupuesto que hizo la semana anterior.

Cada señal se convierte en un cambio de diseño antes de añadir funciones nuevas.

## 7. Después (no ahora)

- **Fase 2:** fotos de la obra en el PDF, duplicar presupuesto, logo en la cabecera,
  plantillas ("baño tipo"), firma del cliente en pantalla, aviso de presupuesto caducado.
- **Fase 3:** copia en la nube opcional y uso desde tablet, con la misma app.
- **Fase 4:** obra aceptada → seguimiento de trabajos y gastos, rentabilidad por obra.
