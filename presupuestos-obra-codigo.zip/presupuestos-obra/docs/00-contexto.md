# Contexto del proyecto — Presupuestos de obra (PWA)

> Documento de traspaso. Si retomas este proyecto en otra sesión, lee esto primero y luego
> `01-estrategia-producto.md`, `02-arquitectura.md` y `03-fase-1.md`.
> Última actualización: 2026-11-19 · Estado: **MVP de la Fase 1 construido, pendiente de prueba real**.

---

## 1. Qué es

Una **PWA** (aplicación web instalable en el móvil, funciona sin conexión) para que un
**albañil autónomo** haga, guarde y envíe sus **presupuestos de obra** desde el teléfono,
sin depender de plantillas de Word, libretas ni de recordar precios.

El usuario final es **una sola persona**: el padre del promotor del proyecto. No es un
producto para vender a terceros, no hay multiusuario, no hay clientes que se registren.

## 2. Para quién (y qué implica)

| Rasgo | Consecuencia de diseño |
|---|---|
| Albañil autónomo, trabajos de reforma y obra nueva pequeña | Vocabulario de obra: partida, m², ml, ud, peón, material, mano de obra |
| No se maneja con tecnología | Cero registro, cero contraseñas, cero ajustes obligatorios, una cosa por pantalla |
| Trabaja con las manos, a veces con guantes y a pleno sol | Botones grandes, alto contraste, tipografía grande, dictado por voz |
| Está en obra, sin señal o con datos justos | Offline real, no "offline de adorno" |
| Su herramienta real es WhatsApp | El presupuesto termina en un **PDF compartido por WhatsApp** |
| Nunca ha hecho copias de seguridad | La copia de seguridad tiene que ser un botón, o automática y visible |
| **Escribe los precios de memoria**, partida a partida | **El catálogo «Mis precios» es el corazón de la app**: aprende de lo que ya usó |
| **No trabaja con IVA**: es organización personal, no fiscalidad | Importes tal y como se los dice al cliente; ni IVA, ni base imponible, ni facturas |

## 3. Problema que resuelve (el "por qué")

Hoy el presupuesto se hace a mano, se copia de otro presupuesto viejo, se manda por
WhatsApp como foto o texto y se pierde. Consecuencias reales:

- Se reescriben partidas que ya existían.
- Se olvidan materiales o horas al calcular.
- No se sabe qué se presupuestó, ni a qué precio, cuando el cliente llama tres semanas después.
- El presupuesto enviado no parece profesional, y eso resta valor al trabajo.
- No hay histórico de precios propios: cada presupuesto empieza de cero.

## 4. Objetivo de éxito (una sola frase)

**Que haga tres presupuestos reales seguidos, solo, sin llamar a nadie y sin volver al papel.**

Todo lo que no acerque a eso, en la Fase 1, está fuera.

## 5. Decisiones ya tomadas

| # | Decisión | Motivo |
|---|---|---|
| D1 | Es una **PWA**, no una app nativa de tienda | Se instala desde el navegador, sin publicar en Google Play, sin cuentas de desarrollador, actualización instantánea |
| D2 | **Local-first**: los datos viven en el móvil (IndexedDB) | Funciona en obra sin cobertura, sin login, sin depender de un servidor |
| D3 | **Sin registro ni contraseñas** | Cualquier login es un punto de abandono para este usuario |
| D4 | La salida principal es un **PDF** compartido con el menú del sistema (WhatsApp) | Es el formato que ya usa con los clientes |
| D5 | **Sin IVA y sin facturación** | El presupuesto es organización personal: el importe es el que le dice al cliente. Facturar añadiría obligaciones fiscales (Verifactu) que aquí no aportan nada |
| D6 | Español de España, lenguaje de obra, sin anglicismos | "Partida", no "ítem"; "mano de obra", no "labor" |
| D7 | Sincronización en la nube: **opcional y posterior** (Fase 3) | No bloquear el MVP; se añade sin rehacer nada si la capa de datos está aislada |
| D8 | Una sola plantilla de PDF, muy legible, con su nombre y teléfono | El PDF es su carta de presentación; no necesita editor de plantillas |
| D9 | **Catálogo de precios alimentado por el uso**, no por una carga inicial | Nadie rellena un catálogo por gusto; se llena solo al marcar «Guardar en Mis precios» |
| D10 | **Dos modos de cobro**: por medida (cantidad × precio) y **partida entera** (precio cerrado, sin cantidades) | Su forma real de presupuestar es «alicatar el baño: 1.000 €», no «20 €/m²»; obligarle a inventarse metros es fricción en cada partida |
| D11 | **Actualización automática y silenciosa**, nunca a costa de los datos | Él no va a pulsar «actualizar»; la app busca versión nueva al abrir, al volver la conexión y cada 30 min, y solo recarga cuando no está escribiendo ni con una ventana a medias. Los datos viven en IndexedDB, intactos entre versiones |

## 6. Estado actual

- [x] Contexto, estrategia y arquitectura documentados
- [x] Fase 1 definida con criterios de aceptación
- [x] Decisiones de producto confirmadas (local-first, sin IVA, catálogo central)
- [x] MVP de la Fase 1 implementado: lista, editor, partidas, catálogo, PDF, ajustes, copias
- [x] Build de producción y tests de cálculo en verde; app instalable (manifest y service worker)
- [x] **Publicado en producción:** https://presupuestos-de-obra-cuzeqz.freebuff.site
  (el preview queda solo para pruebas: los datos no se comparten entre dominios)
- [ ] **Entrevista / observación con el usuario real** (Fase 0)
- [ ] **Prueba real: tres presupuestos con él** ← criterio de terminado de la fase
- [x] Despliegue a hosting estático (Sites), dominio gratuito de Freebuff

## 7. Supuestos todavía abiertos

1. **Dispositivo**: se asume Android. En iPhone el compartir archivos y la instalación
   cambian ligeramente, pero la app funcionaría igual.
2. **Volumen**: si hace dos presupuestos al mes, el catálogo importa menos que la rapidez.
3. **Nombre y datos reales** para el PDF: se configuran en Ajustes, no en el código.
4. **Validez por defecto** de los presupuestos: 30 días, editable.

## 8. Mapa de documentos y código

| Archivo | Para qué sirve |
|---|---|
| `README.md` | Puerta de entrada y puesta en marcha |
| `01-estrategia-producto.md` | Usuario, objetivos, anti-objetivos, principios de UX, flujos y pantallas |
| `02-arquitectura.md` | Opciones evaluadas, stack, modelo de datos, PWA, PDF, copias de seguridad |
| `03-fase-1.md` | Alcance, backlog con criterios de aceptación y plan de validación |
| `src/lib/repo.ts` | Única puerta a los datos (presupuestos, precios, ajustes) |
| `src/lib/pdf.ts` | Plantilla A4 y generación del PDF |
| `src/lib/copia.ts` | Exportar e importar copia de seguridad |

## 9. Glosario (para no perder el idioma del usuario)

- **Partida**: cada línea del presupuesto ("Alicatado de baño, 25 m², 18 €/m²").
- **Presupuesto**: documento con precio total que se entrega al cliente. No es factura.
- **Obra / trabajo**: el encargo concreto para un cliente.
- **Certificar / aceptar**: el cliente dice que sí al presupuesto.
- **Partida entera (precio cerrado)**: se cobra el trabajo completo en un solo importe,
  con material y mano de obra incluidos; no se ponen metros ni cantidades.
- **m², ml, ud, h, kg**: unidades para cuando sí cobra por medida (metro cuadrado,
  metro lineal, unidad, hora, kilo).
