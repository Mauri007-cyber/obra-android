# Presupuestos de obra — PWA

Aplicación web instalable (PWA) para que un albañil autónomo haga, guarde y envíe sus
presupuestos de obra desde el móvil, sin conexión y sin cuentas de usuario.

**Estado: MVP de la Fase 1 construido y publicado.** Falta la prueba real con el usuario.

- **App (esta es la buena, la que se instala en el móvil):** https://presupuestos-de-obra-cuzeqz.freebuff.site
- **Preview** (para pruebas, no para uso real): https://presupuestos-de-obra-cuzeqz-preview.freebuff.site

> Los datos viven en el móvil, atados al dominio. Los presupuestos creados en el preview no
> aparecen en producción: usa el preview solo para probar con datos de mentira.

## Documentación

| Documento | Contenido |
|---|---|
| [GUIA-TECNICA.md](GUIA-TECNICA.md) | **Cómo presupuesta la app y cómo reutilizarlo en otro proyecto**: modelo, datos, cálculos, mapa de archivos |
| [docs/00-contexto.md](docs/00-contexto.md) | Contexto, usuario, decisiones tomadas, estado y supuestos (leer primero) |
| [docs/01-estrategia-producto.md](docs/01-estrategia-producto.md) | Objetivos, anti-objetivos, principios de UX, flujos y bocetos de pantallas |
| [docs/02-arquitectura.md](docs/02-arquitectura.md) | Opciones evaluadas, stack, modelo de datos, PWA, PDF, copias de seguridad |
| [docs/03-fase-1.md](docs/03-fase-1.md) | Alcance del MVP, backlog con criterios de aceptación y plan de validación |

## El producto en cuatro líneas

1. Abre la app (icono en la pantalla de inicio) y pulsa **+ Nuevo presupuesto**.
2. Escribe o dicta las partidas: concepto, cantidad, unidad y precio. El total se ve siempre.
3. Pulsa **Enviar**: se genera un PDF limpio y se comparte por WhatsApp.
4. Todo queda guardado en el móvil, buscable, con estado (enviado, aceptado, terminado).

Sin IVA, sin facturas: el importe es el que se le dice al cliente.

## Stack

React + TypeScript + Vite · Tailwind CSS · Dexie (IndexedDB) · vite-plugin-pwa · pdf-lib
(cargado solo al generar el PDF) · sin backend.

## Puesta en marcha

```bash
npm install
npm run dev      # desarrollo en http://localhost:3000
npm test         # tests de cálculo y formato
npm run build    # comprobación de tipos + build estático + service worker
npm run iconos   # regenera los iconos de la PWA
```

## Estructura

```
src/
  features/presupuestos/  lista y editor del presupuesto
  features/partidas/      formulario de partida
  features/precios/       catálogo "Mis precios"
  features/ajustes/       datos propios, numeración y copias
  lib/                    datos (repo), cálculos, PDF, copia, compartir, formato
  ui/                     botón, campos, hoja, estado, avisos, iconos
docs/                     producto, arquitectura y Fase 1
```
