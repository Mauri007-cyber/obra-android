import { deflateSync } from 'node:zlib';
import { mkdirSync, writeFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const raiz = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const salida = resolve(raiz, 'public');
mkdirSync(salida, { recursive: true });

const tablaCrc = (() => {
  const tabla = new Uint32Array(256);
  for (let n = 0; n < 256; n += 1) {
    let c = n;
    for (let k = 0; k < 8; k += 1) {
      c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    tabla[n] = c >>> 0;
  }
  return tabla;
})();

function crc32(buffer) {
  let c = 0xffffffff;
  for (const byte of buffer) c = tablaCrc[(c ^ byte) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function trozo(tipo, datos) {
  const largo = Buffer.alloc(4);
  largo.writeUInt32BE(datos.length, 0);
  const cuerpo = Buffer.concat([Buffer.from(tipo, 'ascii'), datos]);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(cuerpo), 0);
  return Buffer.concat([largo, cuerpo, crc]);
}

const FIRMA = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);

function dentro(x, y, x0, y0, x1, y1) {
  return x >= x0 && x <= x1 && y >= y0 && y <= y1;
}

function color(u, v) {
  const pepitas = [
    { x0: 0.24, x1: 0.76, y0: 0.3, y1: 0.375, color: [255, 255, 255] },
    { x0: 0.24, x1: 0.62, y0: 0.445, y1: 0.52, color: [255, 255, 255] },
    { x0: 0.24, x1: 0.52, y0: 0.59, y1: 0.665, color: [212, 128, 60] }
  ];
  for (const p of pepitas) {
    if (dentro(u, v, p.x0, p.y0, p.x1, p.y1)) return p.color;
  }
  return [28, 25, 23];
}

function generar(tamano) {
  const filas = [];
  for (let y = 0; y < tamano; y += 1) {
    const fila = Buffer.alloc(1 + tamano * 4);
    fila[0] = 0;
    for (let x = 0; x < tamano; x += 1) {
      // 2x2 de supermuestreo para bordes suaves
      let r = 0;
      let g = 0;
      let b = 0;
      for (const dx of [0.25, 0.75]) {
        for (const dy of [0.25, 0.75]) {
          const [cr, cg, cb] = color((x + dx) / tamano, (y + dy) / tamano);
          r += cr;
          g += cg;
          b += cb;
        }
      }
      const o = 1 + x * 4;
      fila[o] = Math.round(r / 4);
      fila[o + 1] = Math.round(g / 4);
      fila[o + 2] = Math.round(b / 4);
      fila[o + 3] = 255;
    }
    filas.push(fila);
  }

  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(tamano, 0);
  ihdr.writeUInt32BE(tamano, 4);
  ihdr[8] = 8;
  ihdr[9] = 6;
  ihdr[10] = 0;
  ihdr[11] = 0;
  ihdr[12] = 0;

  return Buffer.concat([
    FIRMA,
    trozo('IHDR', ihdr),
    trozo('IDAT', deflateSync(Buffer.concat(filas), { level: 9 })),
    trozo('IEND', Buffer.alloc(0))
  ]);
}

for (const [nombre, tamano] of [
  ['icono-192.png', 192],
  ['icono-512.png', 512],
  ['icono-maskable.png', 512]
]) {
  writeFileSync(resolve(salida, nombre), generar(tamano));
  console.log(`public/${nombre}`);
}
