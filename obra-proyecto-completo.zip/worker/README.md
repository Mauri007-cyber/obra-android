# Proxy de IA (Cloudflare Workers AI)

Un solo Worker que guarda la clave de Cloudflare y llama al modelo. La app nunca ve la clave:
solo conoce esta dirección.

- Modelo: `@cf/black-forest-labs/flux-2-klein-4b` (4 pasos, hasta 4 imágenes de entrada).
- Cupo: `MAX_DIA` imágenes por dispositivo y día (por defecto 30) dentro de las 10.000 neuronas/día gratis.
- `SIMULADO=1`: no llama al modelo y devuelve la misma foto. Sirve para probar la app sin gastar cupo.

## Puesta en marcha

```bash
cd worker
npm install
npx wrangler login          # una vez, en tu ordenador
npx wrangler deploy
```

Al desplegar, apunta la URL que te da (`https://obra-ia.TU-SUBDOMINIO.workers.dev`) y pégala en la app:
**Obra → Retoque con IA → Engranaje → Dirección del servicio**.

## Comprobarlo sin la app

```bash
curl https://obra-ia.TU-SUBDOMINIO.workers.dev/salud
# {"ok":true,"modelo":"@cf/black-forest-labs/flux-2-klein-4b","simulado":false,"cupoDia":30}

curl -X POST https://obra-ia.TU-SUBDOMINIO.workers.dev/retoque \
  -H 'Content-Type: application/json' \
  -H 'X-Dispositivo: prueba-1' \
  -d "{\"foto\":\"$(base64 -w0 foto.jpg)\",\"prompt\":\"Pon el suelo de tarima clara y las paredes blancas\"}"
```

Respuesta correcta:

```json
{ "imagen": "<base64>", "simulado": false, "ms": 8200, "modelo": "…", "quedan": 29 }
```

## Lo que hay que saber

- **Cupo real:** las 10.000 neuronas/día son del plan gratuito de Workers AI. Con este modelo salen
  bastantes imágenes al día, pero no es ilimitado: el tope de 30 por dispositivo es deliberado.
- **Contador:** se lleva con Cache API (sin base de datos). Para un uso personal es suficiente;
  si algún día quieres rigor, cambia `claveCupo` por una tabla D1 sin tocar la app.
- **Fotos:** no se guardan. Se pasan al modelo y se devuelve la imagen. Cloudflare no las retiene
  (Zero Data Retention en los modelos hospedados).
- **CORS:** abierto, porque también lo usa la vista previa web. La protección real es el cupo y que
  nadie conoce la URL.
- **Pruebas:** `node --test worker/prueba.mjs` (no necesita cuenta ni red).
